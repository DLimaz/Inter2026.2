import React, { useState } from 'react';
import { Logo } from '../../components/Logo';
import { I } from '../../lib/icons';

export function Forgot({ go }) {
  const [email, setEmail] = useState('');
  const [ok, setOk] = useState(false);
  return (
    <main className="min-h-screen flex items-center justify-center px-7" style={{ background: '#E8CEB0' }}>
      <form onSubmit={(e) => { e.preventDefault(); setOk(true); }} className="w-full max-w-md bg-surface rounded-[2rem] shadow-float px-8 py-10 animate-rise">
        <div className="mb-8 flex flex-col items-center">
          <Logo size={64} />
          <h1 className="mt-5 text-2xl font-extrabold">Recuperar senha</h1>
          <p className="mt-2 text-center text-sm text-muted-foreground">Enviaremos um link para redefinir sua senha</p>
        </div>
        {ok ? (
          <div className="rounded-2xl bg-secondary p-4 text-center text-sm flex items-center gap-2 justify-center text-primary">
            <I.CheckCircle size={18} />
            <span>Se existir uma conta com <b>{email}</b>, o link chegará em instantes.</span>
          </div>
        ) : (
          <>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.Mail size={18} /></span>
              <input type="email" placeholder="seu@email.com" value={email} onChange={e => setEmail(e.target.value)}
                className="w-full rounded-2xl border border-border bg-white pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-[#3D4A2E]" style={{ height: 56 }} />
            </div>
            <button type="submit" className="mt-6 w-full h-14 rounded-2xl font-bold text-white shadow-soft transition hover:opacity-90" style={{ background: '#3D4A2E' }}>ENVIAR LINK</button>
          </>
        )}
        <button type="button" onClick={() => go('login')} className="mt-6 w-full text-center text-sm text-muted-foreground hover:text-foreground inline-flex items-center justify-center gap-2">
          <I.ArrowLeft size={16} /> Voltar ao login
        </button>
      </form>
    </main>
  );
}