import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { I } from '../../lib/icons';

export function Signup({ go }) {
  const { register, loading } = useAuth();
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmar, setConfirmar] = useState('');
  const [role, setRole] = useState('cliente');
  const [erro, setErro] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handle = async (e) => {
    e.preventDefault(); setErro('');
    if (senha.length < 6) return setErro('A senha deve ter ao menos 6 caracteres');
    if (senha !== confirmar) return setErro('As senhas não coincidem');
    try { const u = await register({ nome, email, senha, role, telefone }); go(u.role === 'admin' ? 'adminHome' : 'home'); }
    catch (err) { setErro(err.message); }
  };

  const fields = [
    { icon: I.User,  ph: 'Nome completo',   v: nome,      set: setNome,      type: 'text', req: true },
    { icon: I.Mail,  ph: 'E-mail',          v: email,     set: setEmail,     type: 'email', req: true },
    { icon: I.Phone, ph: 'Telefone',        v: telefone,  set: setTelefone,  type: 'text', req: false },
    { icon: I.Lock,  ph: 'Senha',           v: senha,     set: setSenha,     type: showPass ? 'text' : 'password', req: true, toggle: () => setShowPass(v => !v), show: showPass },
    { icon: I.Lock,  ph: 'Confirmar senha', v: confirmar, set: setConfirmar, type: showConfirm ? 'text' : 'password', req: true, toggle: () => setShowConfirm(v => !v), show: showConfirm },
  ];

  return (
    <main className="min-h-screen flex items-center justify-center" style={{ background: '#688662' }}>
      <form onSubmit={handle} className="w-full max-w-md px-7 py-10 lg:px-10 lg:py-12 lg:rounded-[2rem] lg:bg-[#5B7855] lg:shadow-float animate-rise text-white">
        <button type="button" onClick={() => go('login')} className="mb-6 flex size-10 items-center justify-center rounded-full hover:bg-white/10 -ml-2 transition">
          <I.ArrowLeft size={20} />
        </button>
        <h1 className="text-3xl font-extrabold text-white leading-tight">Criar conta</h1>
        <p className="mt-2 text-sm text-white/60">Preencha os dados abaixo</p>
        {erro && <div className="mt-5 rounded-2xl bg-red-500/25 border border-red-400/50 px-4 py-3 text-sm text-white">{erro}</div>}
        <div className="mt-7 space-y-3">
          {fields.map((f, i) => (
            <div key={i} className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground/60 pointer-events-none"><f.icon size={18} /></span>
              <input type={f.type} placeholder={f.ph} value={f.v} onChange={e => f.set(e.target.value)} required={f.req}
                className="w-full rounded-2xl border border-transparent bg-surface pl-12 pr-12 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-white/40 shadow-soft" style={{ height: 56 }} />
              {f.toggle && (
                <button type="button" onClick={f.toggle} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition">
                  {f.show ? <I.EyeOff size={16} /> : <I.Eye size={16} />}
                </button>
              )}
            </div>
          ))}
        </div>
        <p className="mt-6 mb-3 text-xs font-bold text-white/60 uppercase tracking-widest">Você é:</p>
        <div className="flex gap-3 mb-7">
          {[{ v: 'cliente', l: 'Cliente', icon: I.ShoppingBag }, { v: 'admin', l: 'Vendedor', icon: I.Store }].map(o => (
            <button key={o.v} type="button" onClick={() => setRole(o.v)}
              className={`flex-1 rounded-2xl border-2 p-4 font-bold text-sm transition flex flex-col items-center gap-1.5 ${role === o.v ? 'border-white bg-white text-[#688662]' : 'border-white/30 bg-transparent text-white'}`}>
              <o.icon size={20} />{o.l}
            </button>
          ))}
        </div>
        <button type="submit" disabled={loading}
          className="w-full h-14 rounded-2xl font-bold text-white text-base shadow-soft transition hover:opacity-90 active:scale-[.97] disabled:opacity-50"
          style={{ background: '#1C2120' }}>
          {loading ? 'CADASTRANDO…' : 'CADASTRAR'}
        </button>
        <p className="mt-6 text-center text-sm text-white/70">
          Já tem uma conta? <button type="button" className="font-bold text-white underline" onClick={() => go('login')}>Faça login</button>
        </p>
      </form>
    </main>
  );
}