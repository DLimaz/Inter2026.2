import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/ui/Button';
import { Logo } from '../../components/Logo';
import { I } from '../../lib/icons';

export function Login({ go }) {
  const { login, loading } = useAuth();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [erro, setErro] = useState('');
  const [slide, setSlide] = useState(0);

  const handleEntrar = async (e) => {
    e.preventDefault(); setErro('');
    try { const u = await login(email, senha); go(u.role === 'admin' ? 'adminHome' : 'home'); }
    catch (err) { setErro(err.message); }
  };

  const SLIDES = [
    { img: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=1400&q=80&auto=format&fit=crop',
      tag: 'Bem-vindo de volta',
      titulo: <>O sabor que mora <span className="text-[#E8CEB0]">pertinho</span> de você.</>,
      sub: 'Bolos, doces e salgados artesanais das melhores confeitarias da sua região.' },
    { img: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=1400&q=80&auto=format&fit=crop',
      tag: 'Feito com amor',
      titulo: <>Cada <span className="text-[#E8CEB0]">doce</span> tem uma história.</>,
      sub: 'Brigadeiros, beijinhos e trufas preparados à mão por quem entende.' },
    { img: 'https://images.pexels.com/photos/32402072/pexels-photo-32402072.jpeg',
      tag: 'Quentinhos do forno',
      titulo: <>Salgados <span className="text-[#E8CEB0]">crocantes</span>, recheios generosos.</>,
      sub: 'Coxinhas, empadas, pão de queijo — feitos na hora, direto pra você.' },
    { img: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=1400&q=80&auto=format&fit=crop',
      tag: 'Para cada momento',
      titulo: <>Do café da <span className="text-[#E8CEB0]">manhã</span> à festa.</>,
      sub: 'Encontre a confeitaria perfeita perto de você, em minutos.' },
  ];

  useEffect(() => {
    const id = setInterval(() => setSlide(s => (s + 1) % SLIDES.length), 5000);
    return () => clearInterval(id);
  }, []);

  const current = SLIDES[slide];

  return (
    <main className="min-h-screen lg:flex" style={{ background: '#E8CEB0' }}>
      <div className="relative lg:w-1/2 lg:min-h-screen overflow-hidden lg:rounded-r-[3rem]">
        {SLIDES.map((s, i) => (
          <div key={i} className="absolute inset-0 transition-opacity duration-[1400ms] ease-in-out" style={{ opacity: i === slide ? 1 : 0 }}>
            <img src={s.img} alt="" className="w-full h-full object-cover transition-transform duration-[7000ms] ease-out" style={{ transform: i === slide ? 'scale(1.08)' : 'scale(1)' }} />
          </div>
        ))}
        <div className="absolute inset-0 z-10 pointer-events-none" style={{ background: 'linear-gradient(180deg, rgba(28,33,32,0.15) 0%, rgba(28,33,32,0.55) 55%, rgba(28,33,32,0.92) 100%)' }} />
        <div className="relative z-20 h-64 lg:h-screen flex flex-col justify-end lg:justify-between p-7 lg:p-12 text-white">
          <div className="hidden lg:flex items-center gap-3">
            <Logo size={52} dark />
            <div>
              <p className="text-sm font-extrabold tracking-[0.15em] leading-none">DOCES & SALGADOS</p>
              <p className="text-[10px] text-white/60 tracking-widest mt-1">FEITO PERTO DE VOCÊ</p>
            </div>
          </div>
          <div>
            <div key={`tag-${slide}`} className="animate-rise">
              <p className="hidden lg:block text-xs font-bold uppercase tracking-[0.25em] text-white/55 mb-3">{current.tag}</p>
              <h2 className="text-2xl lg:text-4xl xl:text-5xl font-extrabold leading-tight max-w-md">{current.titulo}</h2>
              <p className="mt-3 text-sm lg:text-base text-white/75 max-w-md leading-relaxed">{current.sub}</p>
            </div>
            <div className="hidden lg:flex items-center gap-3 mt-6">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur px-4 py-2 text-xs font-bold">
                <I.Star size={14} className="fill-[#E8CEB0] text-[#E8CEB0]" /> 4,9 · 2,3k avaliações
              </div>
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur px-4 py-2 text-xs font-bold">
                <I.Clock size={14} /> 25–35 min
              </div>
            </div>
            <div className="flex items-center gap-2 mt-6">
              {SLIDES.map((_, i) => (
                <button key={i} onClick={() => setSlide(i)} aria-label={`Slide ${i + 1}`}
                  className="h-1.5 rounded-full transition-all duration-500"
                  style={{ width: i === slide ? 28 : 8, background: i === slide ? '#E8CEB0' : 'rgba(255,255,255,0.35)' }} />
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="lg:w-1/2 lg:flex lg:items-center lg:justify-center lg:min-h-screen lg:overflow-y-auto">
        <form onSubmit={handleEntrar} className="w-full max-w-md mx-auto px-7 py-10 lg:px-10 animate-rise">
          <div className="lg:hidden mb-7 flex flex-col items-center text-center">
            <Logo size={64} />
            <h1 className="mt-5 text-2xl leading-tight font-extrabold tracking-[0.15em]">DOCES &<br />SALGADOS</h1>
            <p className="mt-2 text-xs font-medium text-[#5C4A35]">Faça login para continuar</p>
          </div>
          <div className="hidden lg:block mb-8">
            <h1 className="text-3xl font-extrabold leading-tight">Entrar</h1>
            <p className="mt-1.5 text-sm font-medium text-[#5C4A35]">Acesse sua conta para continuar pedindo.</p>
          </div>
          {erro && <div className="mb-4 rounded-2xl bg-red-100 border border-red-300 px-4 py-3 text-sm text-red-700">{erro}</div>}
          <div className="space-y-3">
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.User size={18} /></span>
              <input type="email" placeholder="Nome ou e-mail" value={email} onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-2xl border border-border bg-white pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-[#3D4A2E] transition" style={{ height: 56 }} />
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.Lock size={18} /></span>
              <input type={showPass ? 'text' : 'password'} placeholder="Senha" value={senha} onChange={(e) => setSenha(e.target.value)}
                className="w-full rounded-2xl border border-border bg-white pl-12 pr-12 text-sm outline-none focus:ring-2 focus:ring-[#3D4A2E] transition" style={{ height: 56 }} />
              <button type="button" onClick={() => setShowPass((v) => !v)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition">
                {showPass ? <I.EyeOff size={16} /> : <I.Eye size={16} />}
              </button>
            </div>
          </div>
          <button type="button" onClick={() => go('forgot')} className="ml-auto block mt-3 text-xs font-bold text-[#5C4A35] hover:text-[#1C2120] transition">Esqueceu sua senha?</button>
          <Button type="submit" size="lg" className="mt-6" disabled={loading} style={{ background: '#3D4A2E', color: '#FFFFFF' }}>
            {loading ? 'ENTRANDO…' : 'ENTRAR'}
          </Button>
          <p className="mt-5 text-center text-sm font-medium text-[#5C4A35]">
            Ainda não tem uma conta?{' '}
            <button type="button" className="font-bold underline underline-offset-2 text-[#1C2120]" onClick={() => go('signup')}>Cadastre-se</button>
          </p>
          <div className="my-6 flex items-center gap-3 text-[10px] uppercase tracking-widest text-[#5C4A35]/70">
            <span className="h-px flex-1 bg-border" /> ou <span className="h-px flex-1 bg-border" />
          </div>
          <button type="button" onClick={() => go('signup')}
            className="flex items-center justify-center gap-2 h-14 w-full rounded-2xl border-2 border-[#5C4A35]/30 text-[#5C4A35] font-bold text-sm hover:bg-[#5C4A35]/5 transition">
            <I.User size={16} /> Acessar como visitante
          </button>
          <div className="mt-6 rounded-2xl bg-white/50 px-4 py-3 text-center text-xs text-[#1C2120]">
            <p className="font-bold mb-1">Contas de teste</p>
            <p className="text-[#5C4A35]">cliente@teste.com · vendedor@teste.com</p>
            <p className="text-[#5C4A35]/80 mt-0.5">senha: 123456</p>
          </div>
        </form>
      </div>
    </main>
  );
}