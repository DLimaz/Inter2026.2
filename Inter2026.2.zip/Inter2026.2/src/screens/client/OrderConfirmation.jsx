import React, { useState, useEffect } from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Button } from '../../components/ui/Button';
import { PixBlock } from '../../components/PixBlock';
import { I } from '../../lib/icons';
import { DB } from '../../lib/db';
import { money } from '../../lib/geo';

export function OrderConfirmation({ go, pedidoId, telefone }) {
  const [pedido, setPedido] = useState(null);
  const [store, setStore] = useState(null);

  useEffect(() => { if (pedidoId) DB.get('orders', pedidoId).then(setPedido); }, [pedidoId]);
  useEffect(() => { if (pedido?.storeId) DB.get('stores', pedido.storeId).then(setStore); }, [pedido]);

  if (!pedido) return <Page screen="orders" go={go} noNav><AppBar title="Pedido" /><p className="text-muted-foreground">Carregando…</p></Page>;

  const texto = encodeURIComponent(`Olá! Fiz o pedido #${pedido.id.slice(-6)} na ${pedido.storeName} — Total ${money(pedido.total)}`);
  const link = `https://wa.me/${telefone || pedido.storePhone}?text=${texto}`;
  const metodoTxt = { credito: 'Cartão de crédito', debito: 'Cartão de débito', pix: 'PIX', dinheiro: 'Dinheiro' };

  return (
    <Page screen="orders" go={go} noNav>
      <div className="flex min-h-[80vh] flex-col items-center justify-center px-6 py-10 animate-rise">
        <div className="flex size-24 items-center justify-center rounded-full text-white shadow-float" style={{ background: '#3D4A2E' }}>
          <I.Check size={40} />
        </div>
        <h1 className="mt-7 text-3xl font-extrabold text-center">Pedido confirmado!</h1>
        <p className="mt-3 text-muted-foreground text-center">{pedido.storeName} já começou a preparar suas delícias.</p>
        <p className="mt-1 text-xs text-muted-foreground">Pedido #{pedido.id.slice(-6)}</p>

        {pedido.metodoPagamento === 'pix' && (
          <div className="mt-6 w-full max-w-sm">
            <PixBlock pixKey={store?.pixKey || 'casaamora@pix.com.br'} pixNome={store?.pixNome || pedido.storeName} valor={pedido.total} />
          </div>
        )}

        <div className="mt-6 w-full max-w-sm rounded-2xl bg-secondary px-6 py-4 text-center text-primary">
          <span className="text-xs font-bold uppercase tracking-wide">Previsão de entrega</span>
          <p className="mt-1 text-xl font-extrabold">
            {pedido.tipoEntrega === 'hoje' ? `Hoje às ${pedido.horaEntrega}` : `${pedido.dataEntrega} às ${pedido.horaEntrega}`}
          </p>
        </div>

        <div className="mt-6 w-full max-w-sm space-y-2 rounded-2xl bg-surface p-5 shadow-soft text-sm">
          {pedido.items.map(i => (
            <div key={i.productId} className="flex justify-between"><span>{i.quantidade}x {i.nome}</span><span>{money(i.preco * i.quantidade)}</span></div>
          ))}
          <div className="h-px bg-border my-2" />
          <div className="flex justify-between font-extrabold"><span>Total</span><span className="text-terracotta">{money(pedido.total)}</span></div>
          <p className="text-xs text-muted-foreground mt-2">
            Pagamento: {metodoTxt[pedido.metodoPagamento]}
            {pedido.metodoPagamento === 'dinheiro' && ` · Troco ${money(pedido.troco)}`}
          </p>
          {(pedido.metodoPagamento === 'credito' || pedido.metodoPagamento === 'debito') && pedido.cartaoUltimos4 && (
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <I.CreditCard size={12} />
              {pedido.cartaoBandeira ? pedido.cartaoBandeira.toUpperCase() : 'Cartão'} •••• {pedido.cartaoUltimos4}
              {pedido.parcelas > 1 && ` · ${pedido.parcelas}x de ${money(pedido.total / pedido.parcelas)}`}
            </p>
          )}
        </div>

        <a href={link} target="_blank" rel="noopener noreferrer" className="mt-6 w-full max-w-sm">
          <Button size="lg" className="w-full" style={{ background: '#3D4A2E' }}><I.Phone size={20} /> Falar com a loja no WhatsApp</Button>
        </a>
        <div className="mt-3 w-full max-w-sm space-y-2">
          <Button size="lg" variant="ghost" onClick={() => go('orders')}>Acompanhar pedido</Button>
          <Button size="lg" variant="ghost" onClick={() => go('home')}>Voltar ao início</Button>
        </div>
      </div>
    </Page>
  );
}