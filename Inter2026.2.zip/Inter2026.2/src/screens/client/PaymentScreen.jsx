import React, { useState, useEffect, useMemo } from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { PixBlock } from '../../components/PixBlock';
import { CardForm } from '../../components/CardForm';
import { I } from '../../lib/icons';
import { useAuth } from '../../context/AuthContext';
import { useAddress } from '../../context/AddressContext';
import { useCart } from '../../context/CartContext';
import { DB } from '../../lib/db';
import { detectCardBrand, luhnValid } from '../../lib/card';
import { money } from '../../lib/geo';

export function PaymentScreen({ go, reload }) {
  const cart = useCart();
  const { user } = useAuth();
  const { address } = useAddress();
  const [metodo, setMetodo] = useState('pix');
  const [valorPago, setValorPago] = useState('');
  const [erro, setErro] = useState('');
  const [loading, setLoading] = useState(false);
  const [store, setStore] = useState(null);
  const [card, setCard] = useState({ number: '', name: '', expiry: '', cvv: '' });
  const [cardErrors, setCardErrors] = useState({});
  const [parcelas, setParcelas] = useState(1);

  useEffect(() => { if (cart.storeId) DB.get('stores', cart.storeId).then(setStore); }, [cart.storeId]);

  const subtotal = cart.total;
  const taxa = 5;
  const totalFinal = subtotal + taxa;
  const troco = metodo === 'dinheiro' && valorPago ? Math.max(0, Number(valorPago) - totalFinal) : 0;

  const parcelasOpcoes = useMemo(() => {
    const arr = [];
    for (let i = 1; i <= 12; i++) arr.push({ n: i, valor: totalFinal / i });
    return arr;
  }, [totalFinal]);

  const validarCartao = () => {
    const errs = {};
    const digits = card.number.replace(/\D/g, '');
    if (digits.length < 13) errs.number = 'Número incompleto';
    else if (!luhnValid(digits)) errs.number = 'Número de cartão inválido';
    if (!card.name.trim() || card.name.trim().length < 3) errs.name = 'Informe o nome impresso';
    const m = card.expiry.match(/^(\d{2})\/(\d{2})$/);
    if (!m) errs.expiry = 'Use MM/AA';
    else {
      const mes = parseInt(m[1], 10);
      const ano = 2000 + parseInt(m[2], 10);
      if (mes < 1 || mes > 12) errs.expiry = 'Mês inválido';
      else { const expira = new Date(ano, mes, 0, 23, 59, 59); if (expira < new Date()) errs.expiry = 'Cartão expirado'; }
    }
    const cvvMin = detectCardBrand(card.number) === 'amex' ? 4 : 3;
    if (card.cvv.length < cvvMin) errs.cvv = 'CVV incompleto';
    setCardErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const finalizar = async () => {
    setErro('');
    if (metodo === 'dinheiro' && (!valorPago || Number(valorPago) < totalFinal)) return setErro('O valor pago deve ser maior ou igual ao total');
    if (metodo === 'credito' || metodo === 'debito') { if (!validarCartao()) return setErro('Confira os dados do cartão'); }
    setLoading(true);
    try {
      const isCard = metodo === 'credito' || metodo === 'debito';
      const pedido = await DB.add('orders', {
        userId: user.uid, userName: user.nome,
        storeId: cart.storeId, storeName: cart.storeName, storePhone: cart.storePhone,
        items: cart.items,
        tipoEntrega: cart.delivery.tipo,
        dataEntrega: cart.delivery.tipo === 'agendado' ? cart.delivery.data : '',
        horaEntrega: cart.delivery.hora,
        enderecoEntrega: address ? { ...address } : null,
        metodoPagamento: metodo,
        valorPago: metodo === 'dinheiro' ? Number(valorPago) : null,
        troco: metodo === 'dinheiro' ? troco : 0,
        cartaoUltimos4: isCard ? card.number.replace(/\D/g, '').slice(-4) : null,
        cartaoBandeira: isCard ? detectCardBrand(card.number) : null,
        parcelas: metodo === 'credito' ? parcelas : null,
        subtotal, taxa, total: totalFinal,
        status: 'pendente',
        criadoEm: Date.now(),
      });
      const telefone = cart.storePhone;
      if (reload) reload();
      cart.clear();
      go('orderConfirm', { pedidoId: pedido.id, telefone });
    } catch { setErro('Não foi possível finalizar. Tente novamente.'); }
    finally { setLoading(false); }
  };

  const isCard = metodo === 'credito' || metodo === 'debito';
  const opcoes = [
    ['pix',      'PIX',                 I.QrCode],
    ['credito',  'Cartão de Crédito',   I.CreditCard],
    ['debito',   'Cartão de Débito',    I.CreditCard],
    ['dinheiro', 'Dinheiro',            I.Banknote],
  ];

  return (
    <Page screen="orders" go={go} noNav>
      <AppBar title="Finalizar pedido" back={() => go('delivery')} />
      <div className="lg:grid lg:grid-cols-[1fr_380px] lg:gap-6 lg:items-start">
        <div className="px-5 lg:px-0 pb-44 lg:pb-0 space-y-4">
          <section className="rounded-[1.5rem] bg-surface p-5 lg:p-6 shadow-soft">
            <h2 className="font-extrabold mb-3">Endereço de entrega</h2>
            <div className="flex items-center gap-3 rounded-2xl bg-secondary p-3">
              <span className="flex size-10 items-center justify-center rounded-full bg-surface shrink-0"><I.Home size={18} /></span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold">{address?.label || 'Casa'}</p>
                <p className="text-xs text-muted-foreground truncate">{address?.endereco || 'Rua das Flores, 123 — São Paulo'}</p>
              </div>
              <button onClick={() => go('home')} className="text-xs font-bold text-terracotta">Alterar</button>
            </div>
          </section>

          <section className="rounded-[1.5rem] bg-surface p-5 lg:p-6 shadow-soft">
            <h2 className="font-extrabold mb-3">Forma de pagamento</h2>
            <div className="space-y-2">
              {opcoes.map(([v, l, Icon]) => (
                <button key={v} onClick={() => setMetodo(v)}
                  className={`w-full flex items-center gap-3 rounded-2xl border px-4 py-3.5 transition text-left ${metodo === v ? 'border-terracotta bg-terracotta/5' : 'border-border'}`}>
                  <span className={`flex size-5 items-center justify-center rounded-full border-2 shrink-0 ${metodo === v ? 'border-terracotta' : 'border-muted-foreground/40'}`}>
                    {metodo === v && <span className="size-2.5 rounded-full bg-terracotta" />}
                  </span>
                  <Icon size={18} className="text-muted-foreground" />
                  <span className="text-sm font-bold flex-1">{l}</span>
                </button>
              ))}
            </div>

            {metodo === 'pix' && (
              <div className="mt-4">
                <PixBlock pixKey={store?.pixKey || 'casaamora@pix.com.br'} pixNome={store?.pixNome || cart.storeName} valor={totalFinal} />
              </div>
            )}

            {isCard && (
              <div className="mt-4">
                <CardForm data={card} onChange={setCard} errors={cardErrors} />
                {metodo === 'credito' && (
                  <div className="mt-5">
                    <label className="block text-xs font-bold text-muted-foreground mb-1.5">Parcelamento</label>
                    <select value={parcelas} onChange={e => setParcelas(Number(e.target.value))}
                      className="w-full rounded-2xl border border-border bg-surface px-4 text-sm outline-none focus:ring-2 focus:ring-terracotta" style={{ height: 52 }}>
                      {parcelasOpcoes.map(p => <option key={p.n} value={p.n}>{p.n}x de {money(p.valor)} {p.n === 1 ? '(à vista)' : 'sem juros'}</option>)}
                    </select>
                  </div>
                )}
              </div>
            )}

            {metodo === 'dinheiro' && (
              <div className="mt-4">
                <label className="block text-xs font-bold text-muted-foreground mb-2">Valor em dinheiro</label>
                <Input type="number" min={totalFinal} step="0.01" value={valorPago} onChange={e => setValorPago(e.target.value)} placeholder={`Mínimo ${money(totalFinal)}`} />
                {valorPago && Number(valorPago) >= totalFinal && (<p className="mt-2 text-sm text-muted-foreground">Troco: <b className="text-terracotta">{money(troco)}</b></p>)}
              </div>
            )}
          </section>

          {erro && <div className="rounded-2xl bg-red-100 border border-red-300 px-4 py-3 text-sm text-red-700">{erro}</div>}
        </div>

        <div className="px-5 lg:px-0 mt-4 lg:mt-0 lg:sticky lg:top-24">
          <section className="rounded-[1.5rem] bg-surface p-5 lg:p-6 shadow-soft">
            <h2 className="font-extrabold mb-4">Resumo do pedido</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground"><span>{cart.count} {cart.count === 1 ? 'item' : 'itens'}</span><span>{money(subtotal)}</span></div>
              <div className="flex justify-between text-muted-foreground"><span>Taxa de entrega</span><span>{money(taxa)}</span></div>
              <div className="h-px bg-border my-2" />
              <div className="flex justify-between text-lg font-extrabold"><span>Total</span><span>{money(totalFinal)}</span></div>
            </div>
            <Button size="lg" variant="dark" onClick={finalizar} disabled={loading} className="mt-5">
              {loading ? 'PROCESSANDO…' : 'Confirmar pedido'}
            </Button>
            <p className="mt-2 text-[10px] text-muted-foreground text-center">Você será redirecionado para o pagamento</p>
          </section>
        </div>

        <div className="lg:hidden fixed inset-x-0 bottom-0 z-30 mx-auto max-w-2xl bg-background/95 p-5 backdrop-blur">
          <Button size="lg" variant="dark" onClick={finalizar} disabled={loading}>
            {loading ? 'PROCESSANDO…' : 'Confirmar pedido'}
          </Button>
        </div>
      </div>
    </Page>
  );
}