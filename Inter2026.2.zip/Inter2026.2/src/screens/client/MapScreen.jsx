import React, { useState, useEffect, useMemo } from 'react';
import { Page } from '../../components/layout/Page';
import { GoogleMap } from '../../components/GoogleMap';
import { Radar } from '../../components/Radar';
import { Photo, I } from '../../lib/icons';
import { useUserLocation } from '../../hooks/useUserLocation';
import { haversine, fmtKm } from '../../lib/geo';

export function MapScreen({ go, stores, onSelectStore }) {
  const { loc, status, request } = useUserLocation();
  const [mode, setMode] = useState('map');
  const [rangeKm, setRangeKm] = useState(5);
  const [search, setSearch] = useState('');

  useEffect(() => { if (status === 'idle') request(); }, [status, request]);

  const storesWithDistance = useMemo(() => {
    return stores.filter(s => s.ativa !== false).map(s => ({
      ...s,
      distance: loc ? haversine(loc.lat, loc.lng, s.latitude, s.longitude) : Infinity,
    })).sort((a, b) => a.distance - b.distance);
  }, [stores, loc]);

  const filtered = storesWithDistance.filter(s => {
    if (!search) return true;
    const q = search.toLowerCase();
    return s.nome.toLowerCase().includes(q) || (s.descricao || '').toLowerCase().includes(q);
  });

  const within = storesWithDistance.filter(s => !loc || s.distance <= rangeKm);
  const center = loc || { lat: -23.5614, lng: -46.6560 };
  const modes = [['radar', 'Radar'], ['map', 'Mapa'], ['list', 'Lista']];

  return (
    <Page screen="map" go={go} noNav>
      <div className="lg:bg-surface lg:rounded-[1.5rem] lg:p-5 lg:shadow-soft">
        <div className="sticky top-0 z-30 lg:static px-5 lg:px-0 pt-5 lg:pt-0 pb-3" style={{ background: 'transparent' }}>
          <div className="flex items-center gap-2">
            <button onClick={() => go('home')}
              className="lg:hidden flex size-11 items-center justify-center rounded-full bg-surface shadow-soft text-foreground active:scale-95 transition shrink-0">
              <I.ArrowLeft size={18} />
            </button>
            <div className="flex-1 flex rounded-full bg-surface p-1 shadow-soft lg:max-w-sm">
              {modes.map(([v, l]) => (
                <button key={v} onClick={() => setMode(v)}
                  className={`flex-1 rounded-full py-2.5 text-xs font-bold transition ${mode === v ? 'text-white shadow-soft' : 'text-muted-foreground'}`}
                  style={mode === v ? { background: '#1C2120' } : {}}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>

        {mode === 'map' && (
          <div className="lg:grid lg:grid-cols-[1fr_400px] lg:gap-5 lg:mt-4">
            <div className="px-5 lg:px-0 pb-3 lg:pb-0">
              <div className="relative rounded-[1.5rem] overflow-hidden shadow-soft h-[340px] lg:h-[600px]">
                <GoogleMap center={center} zoom={14} height="100%"
                  markers={[
                    ...(loc ? [{ lat: loc.lat, lng: loc.lng, title: 'Você' }] : []),
                    ...filtered.filter(s => s.latitude && s.longitude).map(s => ({ lat: s.latitude, lng: s.longitude, title: s.nome, store: s })),
                  ]}
                  onMarkerClick={(m) => m.store && onSelectStore(m.store)} />
              </div>
            </div>
            <div className="px-5 lg:px-0 pb-32 lg:pb-0 space-y-3">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.Search size={16} /></span>
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar nesta área"
                  className="w-full rounded-full bg-surface pl-11 pr-4 text-sm outline-none shadow-soft" style={{ height: 44 }} />
              </div>
              <button onClick={request} className="inline-flex items-center gap-2 rounded-full bg-surface px-4 py-2 text-xs font-bold shadow-soft">
                <I.Crosshair size={14} /> Centralizar em mim
              </button>
              <div className="lg:max-h-[500px] lg:overflow-y-auto space-y-3 lg:pr-1">
                {filtered.map(s => (
                  <div key={s.id} className="flex items-center gap-3 rounded-2xl bg-surface p-3 shadow-soft">
                    <div className="size-16 rounded-2xl overflow-hidden shrink-0 bg-secondary">
                      <Photo src={s.imagem} alt={s.nome} className="w-full h-full" size={24} icon={<I.Store size={24} />} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-extrabold text-sm truncate">{s.nome}</h3>
                      <p className="text-[11px] text-muted-foreground truncate">{s.descricao}</p>
                      <div className="mt-1 flex items-center gap-3 text-[11px]">
                        <span className="text-muted-foreground inline-flex items-center gap-1"><I.MapPin size={10} /> {fmtKm(s.distance)}</span>
                        <span className="text-terracotta font-bold inline-flex items-center gap-1"><I.Star size={10} className="fill-terracotta" /> {s.avaliacao?.toFixed(1) || '4.8'}</span>
                      </div>
                    </div>
                    <button onClick={() => onSelectStore(s)} className="shrink-0 rounded-full px-3 py-2 text-[11px] font-bold text-white active:scale-95 transition" style={{ background: '#3D4A2E' }}>
                      Ver loja
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {mode === 'radar' && (
          <div className="px-5 lg:px-0 pb-32 lg:pb-0 lg:mt-4 lg:grid lg:grid-cols-[1fr_400px] lg:gap-5">
            <div>
              {status !== 'granted' && (
                <div className="mb-4 rounded-2xl bg-surface px-4 py-3 text-sm flex items-center gap-3 shadow-soft">
                  <I.MapPin size={20} />
                  <span className="flex-1 text-xs">{status === 'loading' ? 'Obtendo sua localização…' : 'Ative a localização para ver o radar.'}</span>
                  <button onClick={request} className="rounded-full px-4 py-1.5 text-xs font-bold text-white" style={{ background: '#1C2120' }}>Ativar</button>
                </div>
              )}
              <section className="rounded-[2rem] bg-surface p-5 shadow-soft">
                <Radar userLoc={loc} stores={storesWithDistance} onSelectStore={onSelectStore} rangeKm={rangeKm} />
                <div className="mt-6">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-muted-foreground">Raio de busca</label>
                    <span className="text-xs font-extrabold text-terracotta">{rangeKm} km</span>
                  </div>
                  <input type="range" min="1" max="10" step="1" value={rangeKm}
                    onChange={e => setRangeKm(Number(e.target.value))} className="w-full accent-terracotta" />
                </div>
              </section>
            </div>
            <div>
              <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wide mb-3 mt-6 lg:mt-0">
                {within.length} {within.length === 1 ? 'loja no raio' : 'lojas no raio'}
              </h2>
              <div className="space-y-3 lg:max-h-[500px] lg:overflow-y-auto lg:pr-1">
                {within.map(s => (
                  <button key={s.id} onClick={() => onSelectStore(s)} className="flex w-full items-center gap-3 rounded-2xl bg-surface p-3 text-left shadow-soft active:scale-[.99] transition">
                    <div className="size-16 rounded-2xl overflow-hidden shrink-0 bg-secondary">
                      <Photo src={s.imagem} alt={s.nome} className="w-full h-full" size={24} icon={<I.Store size={24} />} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-extrabold text-sm truncate">{s.nome}</h3>
                      <p className="text-[11px] text-muted-foreground truncate">{s.descricao}</p>
                      <div className="mt-1 flex items-center gap-3 text-[11px]">
                        <span className="text-muted-foreground inline-flex items-center gap-1"><I.MapPin size={10} /> {fmtKm(s.distance)}</span>
                        <span className="text-terracotta font-bold inline-flex items-center gap-1"><I.Star size={10} className="fill-terracotta" /> {s.avaliacao?.toFixed(1) || '4.8'}</span>
                      </div>
                    </div>
                    <I.ChevronRight size={18} className="text-muted-foreground shrink-0" />
                  </button>
                ))}
                {within.length === 0 && loc && <p className="text-sm text-muted-foreground text-center py-6">Nenhuma loja no raio de {rangeKm}km.</p>}
              </div>
            </div>
          </div>
        )}

        {mode === 'list' && (
          <div className="px-5 lg:px-0 pb-32 lg:pb-0 lg:mt-4 space-y-3">
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.Search size={16} /></span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar nesta área"
                className="w-full rounded-full bg-surface pl-11 pr-4 text-sm outline-none shadow-soft" style={{ height: 48 }} />
            </div>
            <div className="lg:grid lg:grid-cols-2 lg:gap-3 space-y-3 lg:space-y-0">
              {filtered.map(s => (
                <button key={s.id} onClick={() => onSelectStore(s)} className="flex w-full items-center gap-3 rounded-2xl bg-surface p-3 text-left shadow-soft active:scale-[.99] transition">
                  <div className="size-20 rounded-2xl overflow-hidden shrink-0 bg-secondary">
                    <Photo src={s.imagem} alt={s.nome} className="w-full h-full" size={32} icon={<I.Store size={32} />} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-extrabold truncate">{s.nome}</h3>
                    <p className="mt-0.5 text-xs text-muted-foreground truncate">{s.descricao}</p>
                    <div className="mt-1.5 flex gap-3 text-xs">
                      <span className="text-muted-foreground inline-flex items-center gap-1"><I.MapPin size={12} /> {fmtKm(s.distance)}</span>
                      <span className="text-terracotta font-bold inline-flex items-center gap-1"><I.Star size={12} className="fill-terracotta" /> {s.avaliacao?.toFixed(1) || '4.8'}</span>
                    </div>
                  </div>
                  <I.ChevronRight size={18} className="text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </Page>
  );
}