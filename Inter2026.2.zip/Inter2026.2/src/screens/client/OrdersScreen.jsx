import React, { useState } from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Dialog } from '../../components/ui/Dialog';
import { PixBlock } from '../../components/PixBlock';
import { I } from '../../lib/icons';
import { useAuth } from '../../context/AuthContext';
import { money } from '../../lib/geo';

export function OrdersScreen({ go, orders }) {
  const { user } = useAuth();
  const mine = orders.filter(o => o.userId === user?.uid).sort((a, b) => b.criadoEm - a.criadoEm);

  const statusColor = { pendente: 'bg-yellow-500', preparando: 'bg-blue-500', entrega: 'bg-purple-500', concluido: 'bg-green-600', cancelado: 'bg-red-500' };
  const statusLabel = { pendente: 'Pendente', preparando: 'Em preparo', entrega: 'Em entrega', concluido: 'Concluído', cancelado: 'Cancelado' };
  const metodoTxt = { credito: 'Crédito', debito: 'Débito', pix: 'PIX', dinheiro: 'Dinheiro' };
  const [expanded, setExpanded] = useState(null);
  const [pixModal, setPixModal] = useState(null);

  return (
    <Page screen="orders" go={go}>
      <AppBar title="Seus pedidos" />
      <div className="px-5 lg:px-0 pb-32 lg:pb-0 space-y-3 lg:grid lg:grid-cols-2 lg:gap-3 lg:space-y-0 lg:items-start">
        {mine.length === 0 && (
          <div className="text-center py-16 lg:col-span-2">
            <I.Package size={64} className="text-muted-foreground/50 mx-auto" />
            <p className="mt-4 text-muted-foreground text-sm">Você ainda não fez pedidos.</p>
          </div>
        )}
        {mine.map(o => {
          const open = expanded === o.id;
          return (
            <div key={o.id} className="rounded-[1.5rem] bg-surface shadow-soft overflow-hidden">
              <button onClick={() => setExpanded(open ? null : o.id)} className="w-full p-5 text-left">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold inline-flex items-center gap-2"><I.Store size={16} className="text-terracotta" />{o.storeName}</span>
                  <span className={`rounded-full px-3 py-1 text-[10px] font-bold text-white ${statusColor[o.status] || 'bg-gray-500'}`}>{statusLabel[o.status] || o.status}</span>
                </div>
                <p className="text-xs text-muted-foreground mb-3">#{o.id.slice(-6)} · {new Date(o.criadoEm).toLocaleString('pt-BR')}</p>
                <div className="text-sm space-y-1">
                  {o.items.map(i => (<div key={i.productId} className="flex justify-between"><span>{i.quantidade}x {i.nome}</span><span>{money(i.preco * i.quantidade)}</span></div>))}
                </div>
                <div className="h-px bg-border my-3" />
                <div className="flex justify-between font-bold items-center"><span>Total</span><span className="text-terracotta text-lg">{money(o.total)}</span></div>
              </button>
              {open && (
                <div className="px-5 pb-5 pt-1 border-t border-border">
                  <p className="text-xs text-muted-foreground mt-3 flex items-center gap-2"><I.Clock size={14} />{o.tipoEntrega === 'hoje' ? `Hoje às ${o.horaEntrega}` : `${o.dataEntrega} às ${o.horaEntrega}`}</p>
                  {o.enderecoEntrega && <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2"><I.MapPin size={14} />{o.enderecoEntrega.endereco}</p>}
                  <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2"><I.Wallet size={14} />{metodoTxt[o.metodoPagamento]}{o.metodoPagamento === 'dinheiro' && ` · Troco ${money(o.troco)}`}</p>
                  {(o.metodoPagamento === 'credito' || o.metodoPagamento === 'debito') && o.cartaoUltimos4 && (
                    <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                      <I.CreditCard size={14} />{o.cartaoBandeira ? o.cartaoBandeira.toUpperCase() : 'Cartão'} •••• {o.cartaoUltimos4}
                    </p>
                  )}
                  {o.metodoPagamento === 'pix' && (
                    <button onClick={() => setPixModal(o)} className="mt-3 w-full rounded-xl bg-[#1C2120] text-white py-3 text-sm font-bold inline-flex items-center justify-center gap-2 active:scale-[.98] transition">
                      <I.QrCode size={16} /> Ver código PIX
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <Dialog open={!!pixModal} onClose={() => setPixModal(null)}>
        {pixModal && (<><h2 className="mb-3 flex items-center gap-2 text-lg font-extrabold"><I.QrCode size={20} /> PIX do pedido</h2><PixBlock pixKey={null} pixNome={pixModal.storeName} valor={pixModal.total} /></>)}
      </Dialog>
    </Page>
  );
}