import React from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Button } from '../../components/ui/Button';
import { Photo, I } from '../../lib/icons';
import { useCart } from '../../context/CartContext';
import { money } from '../../lib/geo';

export function CartScreen({ go }) {
  const cart = useCart();
  const taxa = 5;

  return (
    <Page screen="orders" go={go} noNav>
      <AppBar title="Meu carrinho" back={() => go('home')} />
      {cart.items.length === 0 ? (
        <div className="py-16 text-center">
          <I.ShoppingBag size={64} className="text-muted-foreground/60 mx-auto" />
          <p className="mt-4 text-muted-foreground">Seu carrinho está vazio</p>
          <Button className="mt-6" onClick={() => go('home')} style={{ background: '#3D4A2E' }}>Ver lojas</Button>
        </div>
      ) : (
        <div className="lg:grid lg:grid-cols-[1fr_380px] lg:gap-6 lg:items-start">
          <div className="px-5 lg:px-0 pb-40 lg:pb-0 space-y-3">
            {cart.items.map(item => (
              <div key={item.productId} className="flex items-center gap-3 rounded-2xl bg-surface p-3 shadow-soft">
                <div className="size-20 rounded-2xl overflow-hidden shrink-0 bg-secondary">
                  <Photo src={item.imagem} alt={item.nome} categoria={item.categoria} className="w-full h-full" size={28} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-sm truncate">{item.nome}</h3>
                  <p className="text-sm font-extrabold text-terracotta mt-1">{money(item.preco)}</p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <button onClick={() => cart.dec(item.productId)} className="flex size-7 items-center justify-center rounded-full bg-secondary"><I.Minus size={12} /></button>
                    <b className="min-w-5 text-center text-sm">{item.quantidade}</b>
                    <button onClick={() => cart.inc(item.productId)} className="flex size-7 items-center justify-center rounded-full bg-secondary"><I.Plus size={12} /></button>
                  </div>
                </div>
                <button onClick={() => cart.remove(item.productId)} className="text-muted-foreground hover:text-red-500 ml-1"><I.Trash size={16} /></button>
              </div>
            ))}
          </div>

          <div className="px-5 lg:px-0 mt-3 lg:mt-0 lg:sticky lg:top-24">
            <section className="rounded-2xl bg-surface p-5 shadow-soft">
              <h2 className="font-extrabold mb-4">Resumo do pedido</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>{money(cart.total)}</span></div>
                <div className="flex justify-between text-muted-foreground"><span>Taxa de entrega</span><span>{money(taxa)}</span></div>
                <div className="h-px bg-border my-2" />
                <div className="flex justify-between text-lg font-extrabold"><span>Total</span><span className="text-terracotta">{money(cart.total + taxa)}</span></div>
              </div>
              <Button size="lg" className="mt-5" onClick={() => go('delivery')} style={{ background: '#3D4A2E' }}>Finalizar pedido</Button>
              <button onClick={() => go('home')} className="mt-3 w-full text-center text-xs font-bold text-muted-foreground hover:text-foreground">Continuar comprando</button>
            </section>
          </div>

          <div className="lg:hidden fixed inset-x-0 bottom-0 z-30 mx-auto max-w-2xl bg-background/95 p-5 backdrop-blur pt-3">
            <Button size="lg" onClick={() => go('delivery')} style={{ background: '#3D4A2E' }}>Finalizar pedido</Button>
          </div>
        </div>
      )}
    </Page>
  );
}