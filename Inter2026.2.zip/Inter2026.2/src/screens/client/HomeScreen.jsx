import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAddress } from '../../context/AddressContext';
import { useUserLocation } from '../../hooks/useUserLocation';
import { Page } from '../../components/layout/Page';
import { AddressPicker } from '../../components/AddressPicker';
import { DoodleBg } from '../../components/DoodleBg';
import { Photo, I } from '../../lib/icons';
import { CATEGORIES } from '../../constants/categories';
import { haversine, fmtKm, money } from '../../lib/geo';

export function HomeScreen({ go, products, stores, onSelectStore }) {
  const { user } = useAuth();
  const { loc, status, request } = useUserLocation();
  const { address } = useAddress();
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState(null);
  const [pickerOpen, setPickerOpen] = useState(false);

  useEffect(() => { if (status === 'idle') request(); }, [status, request]);

  const storesWithDistance = useMemo(() => {
    return stores.filter(s => s.ativa !== false).map(s => ({
      ...s,
      distance: loc ? haversine(loc.lat, loc.lng, s.latitude, s.longitude) : Infinity,
    })).sort((a, b) => a.distance - b.distance);
  }, [stores, loc]);

  const filteredStores = useMemo(() => {
    return storesWithDistance.filter(s => {
      if (query && !s.nome.toLowerCase().includes(query.toLowerCase()) && !s.descricao?.toLowerCase().includes(query.toLowerCase())) return false;
      if (catFilter) {
        const has = products.some(p => p.lojaId === s.id && p.disponivel !== false && p.categoria === catFilter);
        if (!has) return false;
      }
      return true;
    });
  }, [storesWithDistance, query, catFilter, products]);

  const destaques = useMemo(() => products.filter(p => p.emDestaque && p.disponivel !== false).slice(0, 8), [products]);

  const firstName = user?.nome?.split(' ')[0] || 'você';
  const initials = (user?.nome || 'U').split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();
  const featured = storesWithDistance[0];

  const STATS = [
    { i: I.Store, num: '120+', label: 'Lojas parceiras' },
    { i: I.Star,  num: '4,9',  label: 'Avaliação média' },
    { i: I.Clock, num: '25–35min', label: 'Entrega média' },
    { i: I.Heart, num: '12k+', label: 'Clientes felizes' },
  ];

  const STEPS = [
    { i: I.MapPin, titulo: 'Escolha sua loja', desc: 'Veja as confeitarias mais próximas de você pelo mapa ou pela lista.' },
    { i: I.ShoppingBag, titulo: 'Monte seu pedido', desc: 'Bolos, doces, salgados — do jeitinho que você ama, em poucos toques.' },
    { i: I.Package, titulo: 'Receba em casa', desc: 'Entrega rápida e fresquinha, com acompanhamento em tempo real.' },
  ];

  return (
    <Page screen="home" go={go} dark>
      <div className="relative">
        <DoodleBg />

        <header className="relative lg:rounded-[1.5rem] lg:mb-6 px-6 pt-7 pb-4 lg:px-8 lg:py-6 text-white" style={{ background: '#1C2120' }}>

          {/* Topo — mobile: logo + avatar */}
          <div className="flex items-center justify-between lg:hidden">
            <img src="logo.png" alt="Doces & Salgados" className="h-12 w-auto shrink-0 select-none pointer-events-none" />
            <button onClick={() => go('profile')} aria-label="Perfil"
              className="flex size-10 items-center justify-center rounded-full border-2 border-white/20 active:scale-95 transition overflow-hidden"
              style={{ background: '#5C7A4E' }}>
              {user?.avatar ? (
                <img src={user.avatar} alt={user.nome} className="size-full object-cover" />
              ) : (
                <span className="text-xs font-extrabold text-white">{initials}</span>
              )}
            </button>
          </div>

          {/* Localização mobile */}
          <button onClick={() => setPickerOpen(true)}
            className="lg:hidden mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-white/85 min-w-0 max-w-full">
            <I.MapPin size={16} className="shrink-0" />
            <span className="truncate">{address ? address.label : 'Definir endereço'}</span>
            <I.ChevronRight size={14} className="rotate-90 text-white/50 shrink-0" />
          </button>

          {/* Layout desktop */}
          <div className="lg:flex lg:items-center lg:gap-10">
            <img src="logo.png" alt="Doces & Salgados" className="hidden lg:block h-32 w-auto shrink-0 select-none pointer-events-none" />
            <div className="flex-1 lg:max-w-2xl">
              <h1 className="mt-5 lg:mt-0 text-2xl lg:text-3xl font-extrabold leading-tight">Olá, {firstName}!</h1>
              <p className="mt-1 text-sm text-white/55">O que você está procurando hoje?</p>
              <div className="relative mt-4">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none">
                  <I.Search size={16} />
                </span>
                <input value={query} onChange={e => setQuery(e.target.value)}
                  placeholder="Buscar lojas, produtos ou categorias…"
                  className="w-full rounded-full bg-[#FBF6EA] pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground outline-none"
                  style={{ height: 48 }} />
              </div>
            </div>
          </div>
        </header>

        <div className="relative z-10 px-5 lg:px-0 pb-32 lg:pb-12 pt-6 space-y-8">

          {/* Categorias */}
          <section>
            <div className="grid grid-cols-4 lg:grid-cols-8 gap-3 lg:gap-4">
              {CATEGORIES.map(c => {
                const active = catFilter === c.n;
                return (
                  <button key={c.n} onClick={() => setCatFilter(active ? null : c.n)} className="flex flex-col items-center gap-2">
                    <span className="flex size-16 lg:size-20 items-center justify-center rounded-full transition"
                      style={{ background: c.color, color: '#1C2120', border: active ? '2px solid #C1622D' : '2px solid transparent' }}>
                      <c.i size={26} />
                    </span>
                    <span className={`text-xs font-bold ${active ? 'text-terracotta' : 'text-white'}`}>{c.n}</span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Hero */}
          {featured && !catFilter && !query && (
            <button onClick={() => onSelectStore(featured)} className="relative block h-36 lg:h-56 w-full overflow-hidden rounded-[1.5rem] text-left transition hover:scale-[1.005]">
              {featured.imagem && <img src={featured.imagem} alt="" className="absolute inset-0 w-full h-full object-cover" />}
              <div className="absolute inset-0" style={{ background: 'linear-gradient(90deg, rgba(28,33,32,0.95) 0%, rgba(28,33,32,0.6) 55%, rgba(28,33,32,0.15) 100%)' }} />
              <div className="absolute inset-y-0 left-0 flex max-w-[72%] flex-col justify-center p-5 lg:p-8 text-white">
                <span className="font-display text-xl lg:text-3xl font-extrabold leading-tight">Monte sua festa</span>
                <span className="mt-1 text-[11px] lg:text-sm text-white/75">Salgados, doces e muito mais para o seu evento!</span>
              </div>
            </button>
          )}

          {/* Stats */}
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            {STATS.map(s => (
              <div key={s.label} className="rounded-2xl bg-surface p-4 lg:p-5 shadow-soft flex items-center gap-3">
                <span className="flex size-11 lg:size-12 items-center justify-center rounded-full bg-secondary text-primary shrink-0">
                  <s.i size={20} />
                </span>
                <div className="min-w-0">
                  <p className="text-lg lg:text-xl font-extrabold text-foreground leading-none">{s.num}</p>
                  <p className="text-[11px] lg:text-xs text-muted-foreground mt-1">{s.label}</p>
                </div>
              </div>
            ))}
          </section>

          {/* Lojas próximas */}
          <section>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg lg:text-xl font-extrabold text-white">{catFilter ? catFilter : 'Lojas próximas'}</h2>
              <button onClick={() => go('map')} className="text-xs font-bold text-terracotta inline-flex items-center gap-1">Ver todas <I.ChevronRight size={12} /></button>
            </div>
            {status === 'denied' && (
              <div className="mb-4 rounded-2xl bg-white/10 px-4 py-3 text-xs text-white flex items-center gap-2">
                <I.MapPin size={16} /> Ative a localização.
                <button onClick={request} className="ml-auto font-bold underline">Permitir</button>
              </div>
            )}
            {filteredStores.length === 0 && <p className="text-sm text-white/50 py-6 text-center">Nenhuma loja encontrada.</p>}
            <div className="grid grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 lg:gap-4">
              {filteredStores.slice(0, 10).map(s => (
                <button key={s.id} onClick={() => onSelectStore(s)} className="rounded-2xl bg-surface overflow-hidden text-left shadow-soft transition hover:scale-[1.03]">
                  <div className="aspect-square w-full bg-secondary">
                    <Photo src={s.imagem} alt={s.nome} className="w-full h-full" size={28} icon={<I.Store size={28} />} />
                  </div>
                  <div className="p-2 lg:p-3">
                    <h3 className="font-extrabold text-xs lg:text-sm truncate text-foreground">{s.nome}</h3>
                    <p className="text-[10px] lg:text-[11px] text-muted-foreground truncate">{s.descricao}</p>
                    <div className="mt-1 flex items-center gap-2 text-[10px] lg:text-[11px]">
                      <span className="text-terracotta font-bold inline-flex items-center gap-0.5">
                        <I.Star size={10} className="fill-terracotta" /> {s.avaliacao?.toFixed(1) || '4.8'}
                      </span>
                      <span className="text-muted-foreground">· {fmtKm(s.distance)}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Destaques */}
          {destaques.length > 0 && (
            <section>
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg lg:text-xl font-extrabold text-white flex items-center gap-2">
                  <I.Star size={20} className="fill-[#E8CEB0] text-[#E8CEB0]" />
                  Destaques da semana
                </h2>
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
                {destaques.slice(0, 4).map(p => (
                  <div key={p.id} className="rounded-2xl bg-surface overflow-hidden shadow-soft transition hover:scale-[1.02]">
                    <div className="aspect-square w-full bg-secondary">
                      <Photo src={p.imagem} alt={p.nome} categoria={p.categoria} className="w-full h-full" size={48} />
                    </div>
                    <div className="p-3">
                      <p className="text-[10px] font-bold uppercase tracking-wide text-terracotta">{p.categoria}</p>
                      <h3 className="mt-1 text-sm font-extrabold text-foreground line-clamp-2 min-h-10">{p.nome}</h3>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="font-extrabold text-terracotta text-sm">{money(p.preco)}</span>
                        <span className="text-[11px] text-muted-foreground inline-flex items-center gap-0.5">
                          <I.Star size={10} className="fill-terracotta text-terracotta" /> 4.8
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Como funciona */}
          <section>
            <h2 className="text-lg lg:text-xl font-extrabold text-white mb-4">Como funciona</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4">
              {STEPS.map((s, i) => (
                <div key={s.titulo} className="rounded-2xl bg-surface p-5 lg:p-6 shadow-soft">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="flex size-11 items-center justify-center rounded-full text-white font-extrabold shrink-0" style={{ background: '#3D4A2E' }}>
                      <s.i size={20} />
                    </span>
                    <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Passo {i + 1}</span>
                  </div>
                  <h3 className="text-base font-extrabold text-foreground">{s.titulo}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* CTA vendedores */}
          <section>
            <div className="relative overflow-hidden rounded-[1.5rem] p-6 lg:p-8 text-white shadow-soft"
              style={{ background: 'linear-gradient(135deg, #688662 0%, #4F6A4A 100%)' }}>
              <div className="absolute -right-8 -bottom-8 opacity-10 pointer-events-none">
                <I.Store size={180} strokeWidth={1} />
              </div>
              <div className="relative lg:flex lg:items-center lg:justify-between lg:gap-8">
                <div className="max-w-xl">
                  <p className="text-[10px] font-bold uppercase tracking-[.25em] text-white/70">Para vendedores</p>
                  <h3 className="mt-2 text-2xl lg:text-3xl font-extrabold leading-tight">
                    Tem uma confeitaria? Venda com a gente.
                  </h3>
                  <p className="mt-2 text-sm text-white/80 leading-relaxed">
                    Cadastre sua loja em minutos, receba pedidos da sua vizinhança e gerencie tudo pelo painel.
                  </p>
                </div>
                <div className="mt-4 lg:mt-0 shrink-0">
                  <button
                    onClick={() => go('signup')}
                    className="inline-flex items-center gap-2 h-12 px-6 rounded-2xl bg-white text-[#3D4A2E] font-bold text-sm hover:bg-[#FBF6EA] active:scale-95 transition shadow-soft">
                    Cadastrar minha loja <I.ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </section>

        </div>

        <AddressPicker open={pickerOpen} onClose={() => setPickerOpen(false)} />
      </div>
    </Page>
  );
}