import React, { useState } from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Button } from '../../components/ui/Button';
import { I } from '../../lib/icons';
import { useAuth } from '../../context/AuthContext';
import { useFavorites } from '../../hooks/useFavorites';
import { money } from '../../lib/geo';

export function ProductDetail({ go, product, onAddToCart }) {
  const favs = useFavorites(useAuth().user?.uid);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) {
    return <Page screen="home" go={go} noNav><AppBar title="Produto" back={() => go('home')} /><p className="text-muted-foreground">Produto não encontrado.</p></Page>;
  }

  const handleAdd = () => {
    onAddToCart(product, qty);
    setAdded(true);
    setTimeout(() => { setAdded(false); go('cart'); }, 550);
  };

  return (
    <Page screen="home" go={go} noNav>
      <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-start">
        <div className="relative h-[55vh] min-h-96 lg:h-[600px] lg:rounded-[1.5rem] overflow-hidden">
          {product.imagem ? <img src={product.imagem} alt={product.nome} className="absolute inset-0 w-full h-full object-cover" /> : <div className="absolute inset-0 bg-gradient-to-br from-secondary to-background" />}
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-transparent lg:from-transparent" />
          <button onClick={() => go('store')} className="absolute left-5 top-5 flex size-10 items-center justify-center rounded-full bg-white/95 text-foreground shadow-soft"><I.ArrowLeft size={18} /></button>
          <button onClick={() => favs.toggle(product.id)} className="absolute right-5 top-5 flex size-10 items-center justify-center rounded-full bg-white/95 text-foreground shadow-soft">
            <I.Heart size={18} className={favs.has(product.id) ? 'fill-red-500 text-red-500' : ''} />
          </button>
        </div>

        <div className="px-5 lg:px-0 -mt-8 lg:mt-0 relative z-10 pb-44 lg:pb-0">
          <div className="rounded-[1.5rem] bg-surface p-5 lg:p-6 shadow-soft">
            <h1 className="text-2xl lg:text-3xl font-extrabold">{product.nome}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Doces da Estação</p>
            <div className="mt-3 flex items-center justify-between">
              <span className="inline-flex items-center gap-1 text-sm font-bold text-terracotta">
                <I.Star size={16} className="fill-terracotta" /> 4,8
                <span className="text-muted-foreground font-normal">(152 avaliações)</span>
              </span>
              <span className="text-2xl font-extrabold">{money(product.preco)}</span>
            </div>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">{product.descricao}</p>
            <div className="mt-5 flex items-center gap-3">
              <div className="flex items-center gap-4 rounded-2xl bg-secondary px-3 py-2">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="flex size-7 items-center justify-center rounded-full bg-surface shadow-soft"><I.Minus size={14} /></button>
                <b className="min-w-6 text-center text-sm">{qty}</b>
                <button onClick={() => setQty(qty + 1)} className="flex size-7 items-center justify-center rounded-full bg-surface shadow-soft"><I.Plus size={14} /></button>
              </div>
            </div>
            <Button size="lg" className="mt-5" onClick={handleAdd} disabled={added} style={{ background: '#3D4A2E' }}>
              {added ? <><I.Check size={20} /> Adicionado</> : 'Adicionar ao carrinho'}
            </Button>
          </div>
          <div className="mt-5 rounded-[1.5rem] bg-surface p-5 lg:p-6 shadow-soft">
            <h2 className="font-extrabold mb-3">Informações</h2>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p className="flex items-center gap-3"><I.Leaf size={16} className="text-terracotta" /> Peso: 50g (unidade)</p>
              <p className="flex items-center gap-3"><I.Clock size={16} className="text-terracotta" /> Validade: 5 dias</p>
              <p className="flex items-center gap-3"><I.Store size={16} className="text-terracotta" /> Produzido na hora</p>
            </div>
          </div>
        </div>
      </div>
    </Page>
  );
}