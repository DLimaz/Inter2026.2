import React, { useState, useRef, useMemo } from 'react';
import { Page } from '../../components/layout/Page';
import { Dialog } from '../../components/ui/Dialog';
import { I } from '../../lib/icons';
import { useAuth } from '../../context/AuthContext';
import { useAddress } from '../../context/AddressContext';
import { BRAND_STYLE } from '../../lib/card';

export function ProfileScreen({ go, orders = [] }) {
  const { user, logout, updateUser } = useAuth();
  const { address } = useAddress();
  const [open, setOpen] = useState(null);
  const fileRef = useRef(null);

  const cards = useMemo(() => {
    const mine = (orders || []).filter(o => o.userId === user?.uid);
    const map = new Map();
    mine.forEach(o => {
      const isCard = o.metodoPagamento === 'credito' || o.metodoPagamento === 'debito';
      if (!isCard || !o.cartaoUltimos4) return;
      const key = `${o.cartaoBandeira || 'cartao'}-${o.cartaoUltimos4}`;
      const prev = map.get(key);
      if (!prev || o.criadoEm > prev.criadoEm) map.set(key, o);
    });
    return [...map.values()].sort((a, b) => b.criadoEm - a.criadoEm);
  }, [orders, user?.uid]);

  const opts = [
    { icon: I.Package, label: 'Meus pedidos', desc: 'Acompanhe seus pedidos e histórico.', screen: 'orders' },
    { icon: I.Clock, label: 'Em preparo', desc: 'Pedidos em andamento.', screen: 'orders' },
    { icon: I.MapPin, label: 'Endereço de entrega', desc: 'Endereço atual do delivery.', address: true },
    { icon: I.CreditCard, label: 'Formas de pagamento', desc: 'Cartões usados nas suas compras.', cards: true },
    { icon: I.Bell, label: 'Notificações', desc: 'Escolha o que quer receber.', rows: ['Status do pedido — ativado', 'Promoções e cupons — ativado', 'Novidades das lojas — desativado'] },
    { icon: I.Help, label: 'Ajuda e suporte', desc: 'Estamos por aqui.', rows: ['WhatsApp: (11) 99999-0000', 'E-mail: ajuda@docesesalgados.com'] },
    { icon: I.Settings, label: 'Configurações', desc: 'Preferências do app.', rows: ['Tema: escuro', 'Idioma: Português (BR)', 'Localização: ativada'] },
  ];

  const active = open !== null ? opts[open] : null;
  const initials = (user?.nome || 'U').split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();

  const handleAvatar = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { alert('Escolha uma imagem de até 2MB.'); return; }
    const reader = new FileReader();
    reader.onload = async () => { await updateUser({ avatar: reader.result }); };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  return (
    <Page screen="profile" go={go} dark>
      <div className="lg:max-w-2xl lg:mx-auto lg:bg-surface/5 lg:rounded-[2rem] lg:p-8 lg:shadow-float">
        <section className="px-6 pt-12 pb-8 lg:pt-0 text-center text-white">
          <button onClick={() => fileRef.current?.click()}
            className="relative mx-auto block size-24 rounded-full overflow-hidden group active:scale-95 transition"
            aria-label="Trocar foto de perfil">
            {user?.avatar ? (
              <img src={user.avatar} alt={user.nome} className="size-full object-cover" />
            ) : (
              <div className="size-full flex items-center justify-center" style={{ background: '#5C7A4E' }}>
                <span className="text-2xl font-extrabold text-white">{initials}</span>
              </div>
            )}
            <span className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition">
              <I.Settings size={22} className="text-white" />
            </span>
            <span className="absolute right-0 bottom-0 flex size-7 items-center justify-center rounded-full bg-white text-[#1C2120] border-2 border-[#1C2120]">
              <I.Plus size={12} strokeWidth={3} />
            </span>
          </button>

          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatar} />

          <h1 className="mt-5 text-xl font-extrabold">{user?.nome}</h1>
          <p className="mt-1 text-sm text-white/45">{user?.email}</p>
          <p className="mt-3 text-[11px] text-white/40">Toque na foto para alterar</p>

          {user?.avatar && (
            <button onClick={() => updateUser({ avatar: '' })} className="mt-2 text-[11px] text-white/40 hover:text-white/70 underline">
              Remover foto
            </button>
          )}
        </section>

        <div className="px-5 lg:px-0 pb-32 lg:pb-0">
          <div className="rounded-[1.5rem] bg-surface p-3 shadow-float">
            {opts.map((o, i) => (
              <button key={o.label} onClick={() => o.screen ? go(o.screen) : setOpen(i)}
                className="flex w-full items-center gap-4 rounded-2xl p-3.5 text-left hover:bg-background/60 transition">
                <span className="flex size-9 items-center justify-center rounded-full bg-background text-foreground shrink-0"><o.icon size={18} /></span>
                <span className="flex-1 text-sm font-medium text-foreground">
                  {o.label}
                  {o.cards && cards.length > 0 && <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold text-primary">{cards.length}</span>}
                </span>
                <I.ChevronRight size={16} className="text-muted-foreground" />
              </button>
            ))}
          </div>

          <button onClick={() => { logout(); go('login'); }}
            className="mt-4 w-full flex items-center justify-center gap-2 rounded-2xl py-4 font-bold text-sm text-white/85 hover:bg-white/5 transition">
            <I.LogOut size={16} /> Sair
          </button>
        </div>
      </div>

      <Dialog open={open !== null} onClose={() => setOpen(null)}>
        {active && (
          <>
            <h2 className="mb-1 flex items-center gap-3 text-lg font-extrabold">
              <span className="flex size-10 items-center justify-center rounded-full bg-secondary text-primary"><active.icon size={20} /></span>
              {active.label}
            </h2>
            <p className="mb-4 text-sm text-muted-foreground">{active.desc}</p>

            {active.address && (
              address ? (
                <div className="rounded-2xl bg-background p-4">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1">{address.label}</p>
                  <p className="text-sm font-semibold">{address.endereco}</p>
                  <button onClick={() => { setOpen(null); go('home'); }} className="mt-3 w-full rounded-xl bg-surface py-2 text-[11px] font-bold text-primary hover:bg-secondary transition">
                    Alterar endereço
                  </button>
                </div>
              ) : (
                <div className="rounded-2xl border border-dashed border-border bg-background px-4 py-8 text-center">
                  <I.MapPin size={32} className="mx-auto text-muted-foreground/40" />
                  <p className="mt-2 text-sm text-muted-foreground">Nenhum endereço cadastrado</p>
                </div>
              )
            )}

            {active.cards && (
              cards.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-border bg-background px-4 py-8 text-center">
                  <I.CreditCard size={32} className="mx-auto text-muted-foreground/40" />
                  <p className="mt-2 text-sm text-muted-foreground">Você ainda não usou cartão em nenhuma compra.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {cards.map(o => {
                    const style = BRAND_STYLE[o.cartaoBandeira] || BRAND_STYLE.unknown;
                    const isCredito = o.metodoPagamento === 'credito';
                    return (
                      <div key={o.id} className="rounded-2xl bg-background p-4">
                        <div className="flex items-center gap-3">
                          <span className="flex size-11 shrink-0 items-center justify-center rounded-xl text-[9px] font-extrabold text-white" style={{ background: style.bg }}>
                            {style.label ? style.label.slice(0, 4) : 'CARD'}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-bold truncate">{style.label || 'Cartão'} •••• {o.cartaoUltimos4}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {isCredito ? 'Crédito' : 'Débito'}
                              {isCredito && o.parcelas > 1 && ` · ${o.parcelas}x`}
                              {' · '}{new Date(o.criadoEm).toLocaleDateString('pt-BR')}
                            </p>
                          </div>
                          <span className="rounded-full bg-secondary px-2 py-1 text-[9px] font-bold text-primary shrink-0">usado</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )
            )}

            {!active.cards && !active.address && active.rows && (
              <div className="space-y-2">{active.rows.map(r => <div key={r} className="rounded-2xl bg-background px-4 py-3 text-sm font-medium">{r}</div>)}</div>
            )}
          </>
        )}
      </Dialog>
    </Page>
  );
}