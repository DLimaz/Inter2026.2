import React from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Photo, I } from '../../lib/icons';
import { useAuth } from '../../context/AuthContext';
import { useFavorites } from '../../hooks/useFavorites';
import { money } from '../../lib/geo';

export function FavoritesScreen({ go, products, onOpenProduct }) {
  const { user } = useAuth();
  const favs = useFavorites(user?.uid);
  const list = products.filter(p => favs.ids.includes(p.id));

  return (
    <Page screen="favorites" go={go}>
      <AppBar title="Seus favoritos" />
      <div className="px-5 lg:px-0 pb-32 lg:pb-0">
        {list.length === 0 ? (
          <div className="text-center py-16">
            <I.Heart size={64} className="text-muted-foreground/50 mx-auto" />
            <p className="mt-4 text-muted-foreground">Você ainda não favoritou nada.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {list.map(p => (
              <button key={p.id} onClick={() => onOpenProduct(p)} className="rounded-[1.5rem] bg-surface p-3 text-left shadow-soft transition hover:scale-[1.02]">
                <div className="relative">
                  <div className="aspect-square rounded-2xl overflow-hidden bg-secondary">
                    <Photo src={p.imagem} alt={p.nome} categoria={p.categoria} className="w-full h-full" size={48} />
                  </div>
                  <span className="absolute bottom-2 right-2 flex size-7 items-center justify-center rounded-full bg-terracotta text-terracotta-foreground shadow-soft"><I.Heart size={14} className="fill-current" /></span>
                </div>
                <h3 className="mt-3 text-sm font-extrabold line-clamp-2">{p.nome}</h3>
                <p className="mt-1 font-bold text-terracotta text-sm">{money(p.preco)}</p>
              </button>
            ))}
          </div>
        )}
      </div>
    </Page>
  );
}