import React, { useState, useMemo } from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { I } from '../../lib/icons';
import { useCart } from '../../context/CartContext';

export function DeliveryScreen({ go }) {
  const cart = useCart();
  const [erro, setErro] = useState('');

  const horarios = useMemo(() => {
    const arr = [];
    for (let h = 9; h <= 20; h++) {
      arr.push(`${String(h).padStart(2, '0')}:00`);
      if (h < 20) arr.push(`${String(h).padStart(2, '0')}:30`);
    }
    return arr;
  }, []);

  const today = new Date().toISOString().split('T')[0];
  const max = new Date(Date.now() + 90 * 864e5).toISOString().split('T')[0];

  const handleContinue = () => {
    if (cart.delivery.tipo === 'agendado' && !cart.delivery.data) return setErro('Escolha uma data');
    setErro(''); go('payment');
  };

  return (
    <Page screen="orders" go={go} noNav>
      <AppBar title="Entrega" back={() => go('cart')} />
      <div className="px-5 lg:px-0 pb-32 lg:pb-0 lg:max-w-2xl lg:mx-auto">
        <div className="rounded-[1.7rem] bg-surface p-5 lg:p-6 shadow-soft">
          <h2 className="text-lg font-extrabold mb-4">Quando quer receber?</h2>
          <div className="flex gap-3 mb-5">
            {[['hoje', 'Mesmo dia', I.Clock], ['agendado', 'Agendar', I.Settings]].map(([v, l, Icon]) => (
              <button key={v} onClick={() => cart.setDelivery({ tipo: v })}
                className={`flex-1 rounded-2xl border-2 p-3.5 font-bold text-sm transition inline-flex items-center justify-center gap-2 ${cart.delivery.tipo === v ? 'border-[#1C2120] bg-[#1C2120] text-white' : 'border-[#1C2120] text-[#1C2120] bg-transparent'}`}>
                <Icon size={16} /> {l}
              </button>
            ))}
          </div>

          {cart.delivery.tipo === 'agendado' && (
            <>
              <label className="block text-xs font-bold text-muted-foreground mb-2">Data</label>
              <Input type="date" min={today} max={max} value={cart.delivery.data} onChange={e => cart.setDelivery({ data: e.target.value })} className="mb-4" />
            </>
          )}

          <label className="block text-xs font-bold text-muted-foreground mb-2">Horário</label>
          <select value={cart.delivery.hora} onChange={e => cart.setDelivery({ hora: e.target.value })}
            className="w-full rounded-2xl border border-border bg-surface px-4 text-sm outline-none focus:ring-2 focus:ring-terracotta" style={{ height: 52 }}>
            {horarios.map(h => <option key={h}>{h}</option>)}
          </select>

          {erro && <p className="mt-3 text-sm text-red-500">{erro}</p>}

          <div className="mt-6 hidden lg:block">
            <Button size="lg" onClick={handleContinue} style={{ background: '#3D4A2E' }}>Continuar</Button>
          </div>
        </div>
      </div>

      <div className="lg:hidden fixed inset-x-0 bottom-0 z-30 mx-auto max-w-2xl bg-background/95 p-5 backdrop-blur">
        <Button size="lg" onClick={handleContinue} style={{ background: '#3D4A2E' }}>Continuar</Button>
      </div>
    </Page>
  );
}