import React, { useState, useEffect } from 'react';
import { Page } from '../../components/layout/Page';
import { AppBar } from '../../components/layout/AppBar';
import { Photo, I } from '../../lib/icons';
import { useCart } from '../../context/CartContext';
import { money } from '../../lib/geo';

export function StoreMenu({ go, store, products, onAddToCart, onOpenProduct }) {
  const { selectStore, count, total } = useCart();
  const [tab, setTab] = useState('Produtos');
  const [cat, setCat] = useState('Todos');

  useEffect(() => { if (store) selectStore(store); }, [store, selectStore]);

  if (!store) {
    return (
      <Page screen="home" go={go}>
        <AppBar title="Loja" back={() => go('home')} />
        <p className="text-muted-foreground">Loja não encontrada.</p>
      </Page>
    );
  }

  const lojaProducts = products.filter(p => p.lojaId === store.id && p.disponivel !== false);
  const categorias = ['Todos', ...new Set(lojaProducts.map(p => p.categoria))];
  const filtered = cat === 'Todos' ? lojaProducts : lojaProducts.filter(p => p.categoria === cat);

  return (
    <Page screen="home" go={go} noNav>
      <div className="relative h-72 lg:h-72 lg:rounded-[1.5rem] overflow-hidden lg:mb-6 -mx-5 lg:mx-0">
        {store.imagem ? <img src={store.imagem} alt={store.nome} className="absolute inset-0 w-full h-full object-cover" /> : <div className="absolute inset-0 bg-gradient-to-br from-secondary to-background" />}
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-transparent" />
        <button onClick={() => go('home')} className="absolute left-5 top-5 flex size-10 items-center justify-center rounded-full bg-white/95 text-foreground shadow-soft"><I.ArrowLeft size={18} /></button>
        <button className="absolute right-5 top-5 flex size-10 items-center justify-center rounded-full bg-white/95 text-foreground shadow-soft"><I.Heart size={18} /></button>
      </div>

      <div className="px-5 lg:px-0 -mt-10 lg:mt-0 relative z-10">
        <div className="rounded-[1.5rem] bg-surface p-5 lg:p-6 shadow-soft">
          <h1 className="text-2xl lg:text-3xl font-extrabold">{store.nome}</h1>
          <p className="text-sm text-muted-foreground mt-1">{store.descricao}</p>
          <div className="mt-3 flex items-center gap-4 text-xs lg:text-sm">
            <span className="text-terracotta font-bold inline-flex items-center gap-1">
              <I.Star size={14} className="fill-terracotta" /> {store.avaliacao?.toFixed(1) || '4.8'}
              <span className="text-muted-foreground font-normal">(324 avaliações)</span>
            </span>
            <span className="text-muted-foreground inline-flex items-center gap-1"><I.MapPin size={12} /> 0,4 km</span>
          </div>
          <div className="mt-4 flex gap-5 border-b border-border">
            {['Produtos', 'Sobre', 'Avaliações'].map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`pb-2 text-sm font-bold transition border-b-2 -mb-px ${tab === t ? 'border-foreground text-foreground' : 'border-transparent text-muted-foreground'}`}>{t}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="lg:grid lg:grid-cols-[260px_1fr] lg:gap-6 lg:mt-6">
        <aside className="hidden lg:block">
          <div className="sticky top-24 rounded-2xl bg-surface p-4 shadow-soft">
            <h3 className="font-extrabold text-sm mb-3 px-2">Categorias</h3>
            {categorias.map(t => (
              <button key={t} onClick={() => setCat(t)}
                className={`block w-full text-left rounded-xl px-3 py-2.5 text-sm font-bold transition ${cat === t ? 'bg-[#3D4A2E] text-white' : 'text-foreground/70 hover:bg-muted'}`}>
                {t}
              </button>
            ))}
          </div>
        </aside>

        <div className="min-w-0">
          <div className="lg:hidden px-5 pt-5 pb-3">
            <div className="flex gap-2 overflow-x-auto hide-scrollbar">
              {categorias.map(t => (
                <button key={t} onClick={() => setCat(t)}
                  className={`rounded-full px-4 py-2 text-xs font-bold transition whitespace-nowrap ${cat === t ? 'bg-[#3D4A2E] text-white' : 'bg-surface text-foreground border border-border'}`}>{t}</button>
              ))}
            </div>
          </div>

          <div className="px-5 lg:px-0 lg:pt-0 pb-40 lg:pb-12 space-y-3 lg:grid lg:grid-cols-2 xl:grid-cols-3 lg:gap-4 lg:space-y-0">
            {filtered.map(p => (
              <article key={p.id} className="flex items-center gap-3 rounded-2xl bg-surface p-3 shadow-soft">
                <button onClick={() => onOpenProduct(p)} className="size-20 lg:size-24 rounded-2xl overflow-hidden shrink-0 bg-secondary">
                  <Photo src={p.imagem} alt={p.nome} categoria={p.categoria} className="w-full h-full" size={28} />
                </button>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-sm truncate">{p.nome}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{p.descricao}</p>
                  <p className="font-extrabold text-terracotta text-sm mt-1">{money(p.preco)}</p>
                </div>
                <button onClick={() => onAddToCart(p)} className="flex size-10 items-center justify-center rounded-full shrink-0 text-white shadow-soft active:scale-95 transition" style={{ background: '#3D4A2E' }}>
                  <I.Plus size={18} />
                </button>
              </article>
            ))}
            {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">Nenhum produto nesta categoria.</p>}
          </div>
        </div>
      </div>

      {count > 0 && (
        <button onClick={() => go('cart')} className="lg:hidden fixed bottom-5 left-1/2 -translate-x-1/2 z-40 flex items-center gap-4 rounded-full pl-5 pr-2 py-2 text-white shadow-float"
          style={{ background: '#3D4A2E', width: 'calc(100% - 2.5rem)', maxWidth: '36rem' }}>
          <span className="flex items-center gap-2 text-sm font-bold"><I.Cart size={18} /> Ver carrinho ({count})</span>
          <span className="ml-auto rounded-full bg-white/15 px-4 py-2 text-sm font-extrabold">{money(total)}</span>
        </button>
      )}
    </Page>
  );
}