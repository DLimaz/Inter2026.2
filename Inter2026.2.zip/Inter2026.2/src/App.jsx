import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AddressProvider } from './context/AddressContext';
import { CartProvider, useCart } from './context/CartContext';
import { DB } from './lib/db';

// Auth
import { Login } from './screens/auth/Login';
import { Signup } from './screens/auth/Signup';
import { Forgot } from './screens/auth/Forgot';

// Cliente
import { HomeScreen } from './screens/client/HomeScreen';
import { MapScreen } from './screens/client/MapScreen';
import { StoreMenu } from './screens/client/StoreMenu';
import { ProductDetail } from './screens/client/ProductDetail';
import { CartScreen } from './screens/client/CartScreen';
import { DeliveryScreen } from './screens/client/DeliveryScreen';
import { PaymentScreen } from './screens/client/PaymentScreen';
import { OrderConfirmation } from './screens/client/OrderConfirmation';
import { ProfileScreen } from './screens/client/ProfileScreen';
import { OrdersScreen } from './screens/client/OrdersScreen';
import { FavoritesScreen } from './screens/client/FavoritesScreen';

function CartBridge({ children }) {
  const cart = useCart();
  useEffect(() => {
    const h = (e) => {
      const { product, qty } = e.detail;
      if (cart.storeId && cart.storeId !== product.lojaId) cart.clear();
      cart.addItem(product, qty);
    };
    window.addEventListener('ds:addToCart', h);
    return () => window.removeEventListener('ds:addToCart', h);
  }, [cart]);
  return children;
}

function AppInner() {
  const { user } = useAuth();
  const [screen, setScreen] = useState(user ? 'home' : 'login');
  const [screenParams, setScreenParams] = useState({});
  const [stores, setStores] = useState([]);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);

  const reload = useCallback(() => {
    DB.all('stores').then(setStores);
    DB.all('products').then(setProducts);
    DB.all('orders').then(setOrders);
  }, []);
  useEffect(() => { reload(); }, [reload]);

  useEffect(() => {
    if (!user) setScreen('login');
    else if (['login', 'signup', 'forgot'].includes(screen)) {
      // Admin também cai em 'home' por enquanto (telas de admin vêm depois)
      setScreen('home');
    }
  }, [user]);

  const go = useCallback((next, params = {}) => {
    setScreen(next); setScreenParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const [currentStore, setCurrentStore] = useState(null);
  const [currentProduct, setCurrentProduct] = useState(null);

  const handleSelectStore = (store, product = null) => {
    setCurrentStore(store);
    if (product) { setCurrentProduct(product); go('product'); }
    else { setCurrentProduct(null); go('store'); }
  };
  const handleAddToCart = (product, qty = 1) => {
    window.dispatchEvent(new CustomEvent('ds:addToCart', { detail: { product, qty } }));
  };
  const handleOpenProduct = (product) => { setCurrentProduct(product); go('product'); };

  return (
    <CartBridge>
      {screen === 'login' && <Login go={go} />}
      {screen === 'signup' && <Signup go={go} />}
      {screen === 'forgot' && <Forgot go={go} />}

      {screen === 'home' && <HomeScreen go={go} products={products} stores={stores} onSelectStore={handleSelectStore} />}
      {screen === 'map' && <MapScreen go={go} stores={stores} onSelectStore={handleSelectStore} />}
      {screen === 'store' && <StoreMenu go={go} store={currentStore} products={products} onAddToCart={handleAddToCart} onOpenProduct={handleOpenProduct} />}
      {screen === 'product' && <ProductDetail go={go} product={currentProduct} onAddToCart={handleAddToCart} />}
      {screen === 'cart' && <CartScreen go={go} />}
      {screen === 'delivery' && <DeliveryScreen go={go} />}
      {screen === 'payment' && <PaymentScreen go={go} reload={reload} />}
      {screen === 'orderConfirm' && <OrderConfirmation go={go} pedidoId={screenParams.pedidoId} telefone={screenParams.telefone} />}
      {screen === 'profile' && <ProfileScreen go={go} orders={orders} />}
      {screen === 'orders' && <OrdersScreen go={go} orders={orders} />}
      {screen === 'favorites' && <FavoritesScreen go={go} products={products} onOpenProduct={handleOpenProduct} />}
    </CartBridge>
  );
}

export default function Root() {
  return (
    <AuthProvider>
      <AddressProvider>
        <CartProvider>
          <AppInner />
        </CartProvider>
      </AddressProvider>
    </AuthProvider>
  );
}