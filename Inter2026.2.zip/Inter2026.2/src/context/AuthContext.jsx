import React, { createContext, useContext, useState } from 'react';
import { DB, SESSION_KEY } from '../lib/db';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { const r = localStorage.getItem(SESSION_KEY); return r ? JSON.parse(r) : null; } catch { return null; }
  });
  const [loading, setLoading] = useState(false);
  const persist = (u) => {
    setUser(u);
    if (u) localStorage.setItem(SESSION_KEY, JSON.stringify(u));
    else localStorage.removeItem(SESSION_KEY);
  };
  const login = async (email, senha) => {
    setLoading(true);
    try {
      const users = await DB.all('users');
      const found = users.find(u => (u.email === email || u.nome === email) && u.senha === senha);
      if (!found) throw new Error('E-mail ou senha inválidos');
      const { senha: _s, ...safe } = found;
      persist(safe);
      return safe;
    } finally { setLoading(false); }
  };
  const register = async ({ nome, email, senha, role, telefone }) => {
    setLoading(true);
    try {
      const users = await DB.all('users');
      if (users.some(u => u.email === email)) throw new Error('Este e-mail já está cadastrado');
      const novo = await DB.add('users', { nome, email, senha, role, telefone: telefone || '' });
      const { senha: _s, ...safe } = novo;
      persist(safe);
      return safe;
    } finally { setLoading(false); }
  };
  const logout = () => persist(null);
  const updateUser = async (patch) => {
    if (!user) return;
    await DB.update('users', user.uid, patch);
    const { senha: _s, ...safe } = { ...user, ...patch };
    persist(safe);
  };
  return <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);