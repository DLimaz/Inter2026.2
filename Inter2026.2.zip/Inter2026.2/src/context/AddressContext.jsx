import React, { createContext, useContext, useState } from 'react';
import { ADDRESS_KEY } from '../lib/db';

const AddressContext = createContext(null);

export function AddressProvider({ children }) {
  const [address, setAddress] = useState(() => {
    try { return JSON.parse(localStorage.getItem(ADDRESS_KEY)) || null; } catch { return null; }
  });
  const save = (addr) => {
    setAddress(addr);
    if (addr) localStorage.setItem(ADDRESS_KEY, JSON.stringify(addr));
    else localStorage.removeItem(ADDRESS_KEY);
  };
  return <AddressContext.Provider value={{ address, save }}>{children}</AddressContext.Provider>;
}

export const useAddress = () => useContext(AddressContext);