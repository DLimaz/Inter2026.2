import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { CART_KEY } from '../lib/db';

const CartContext = createContext(null);
const CART_DEFAULT = { storeId: null, storeName: '', storePhone: '', items: [], delivery: { tipo: 'hoje', hora: '18:00', data: '' } };

export function CartProvider({ children }) {
  const [state, setState] = useState(() => {
    try { const r = localStorage.getItem(CART_KEY); return r ? JSON.parse(r) : CART_DEFAULT; } catch { return CART_DEFAULT; }
  });
  useEffect(() => { localStorage.setItem(CART_KEY, JSON.stringify(state)); }, [state]);

  const selectStore = useCallback((store) => setState(s => {
    const same = s.storeId === store.id;
    return { ...s, storeId: store.id, storeName: store.nome, storePhone: store.telefone, items: same ? s.items : [] };
  }), []);
  const addItem = useCallback((product, qty = 1) => setState(s => {
    const ex = s.items.find(i => i.productId === product.id);
    if (ex) return { ...s, items: s.items.map(i => i.productId === product.id ? { ...i, quantidade: i.quantidade + qty } : i) };
    return { ...s, items: [...s.items, { productId: product.id, nome: product.nome, preco: product.preco, categoria: product.categoria, imagem: product.imagem, quantidade: qty }] };
  }), []);
  const inc = useCallback((id) => setState(s => ({ ...s, items: s.items.map(i => i.productId === id ? { ...i, quantidade: i.quantidade + 1 } : i) })), []);
  const dec = useCallback((id) => setState(s => ({ ...s, items: s.items.map(i => i.productId === id ? { ...i, quantidade: i.quantidade - 1 } : i).filter(i => i.quantidade > 0) })), []);
  const remove = useCallback((id) => setState(s => ({ ...s, items: s.items.filter(i => i.productId !== id) })), []);
  const setDelivery = useCallback((patch) => setState(s => ({ ...s, delivery: { ...s.delivery, ...patch } })), []);
  const clear = useCallback(() => setState(CART_DEFAULT), []);

  const total = state.items.reduce((sum, i) => sum + i.preco * i.quantidade, 0);
  const count = state.items.reduce((sum, i) => sum + i.quantidade, 0);

  return (
    <CartContext.Provider value={{ ...state, total, count, selectStore, addItem, inc, dec, remove, setDelivery, clear }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);