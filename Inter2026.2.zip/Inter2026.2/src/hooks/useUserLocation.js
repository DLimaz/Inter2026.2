import { useState, useCallback } from 'react';

export function useUserLocation() {
  const [loc, setLoc] = useState(null);
  const [status, setStatus] = useState('idle');
  const request = useCallback(() => {
    if (!navigator.geolocation) { setStatus('denied'); return; }
    setStatus('loading');
    navigator.geolocation.getCurrentPosition(
      (pos) => { setLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setStatus('granted'); },
      () => setStatus('denied'),
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 }
    );
  }, []);
  return { loc, status, request };
}