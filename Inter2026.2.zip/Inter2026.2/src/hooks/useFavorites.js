import { useState, useEffect } from 'react';
import { FAV_KEY } from '../lib/db';

export function useFavorites(userId) {
  const key = userId ? `${FAV_KEY}_${userId}` : null;
  const [ids, setIds] = useState([]);
  useEffect(() => {
    if (!key) { setIds([]); return; }
    try { setIds(JSON.parse(localStorage.getItem(key) || '[]')); } catch { setIds([]); }
  }, [key]);
  const toggle = (id) => {
    if (!key) return;
    const next = ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id];
    setIds(next);
    localStorage.setItem(key, JSON.stringify(next));
  };
  return { ids, toggle, has: (id) => ids.includes(id) };
}