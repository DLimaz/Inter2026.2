import { useEffect, useState } from 'react';
import { loadGoogleMaps } from '../lib/googleMaps';

export function useGoogleMaps() {
  const [state, setState] = useState({ ready: false, error: null });
  useEffect(() => {
    loadGoogleMaps().then(() => setState({ ready: true, error: null })).catch(e => setState({ ready: false, error: e.message }));
  }, []);
  return state;
}