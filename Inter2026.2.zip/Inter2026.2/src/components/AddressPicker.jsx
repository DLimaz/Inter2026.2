import React, { useState, useRef, useEffect } from 'react';
import { useAddress } from '../context/AddressContext';
import { useGoogleMaps } from '../hooks/useGoogleMaps';
import { GoogleMap } from './GoogleMap';
import { AppBar } from './layout/AppBar';
import { Button } from './ui/Button';
import { I } from '../lib/icons';

export function AddressPicker({ open, onClose }) {
  const { address, save } = useAddress();
  const { ready } = useGoogleMaps();
  const autoRef = useRef(null);
  const placesRef = useRef(null);
  const [query, setQuery] = useState('');
  const [sugg, setSugg] = useState([]);
  const [picked, setPicked] = useState(null);
  const [label, setLabel] = useState('Casa');
  const [customLabel, setCustomLabel] = useState('');
  const [loadingAddr, setLoadingAddr] = useState(false);
  const defaultCenter = { lat: -23.5614, lng: -46.6560 };

  useEffect(() => {
    if (!ready || !open) return;
    autoRef.current = new window.google.maps.places.AutocompleteService();
    placesRef.current = new window.google.maps.places.PlacesService(document.createElement('div'));
  }, [ready, open]);

  useEffect(() => {
    if (open) {
      setPicked(address || null);
      const isPreset = ['Casa', 'Trabalho', 'Outro'].includes(address?.label);
      setLabel(isPreset || !address?.label ? (address?.label || 'Casa') : 'Outro');
      setCustomLabel(isPreset ? '' : (address?.label || ''));
      setQuery(''); setSugg([]); setLoadingAddr(false);
    }
  }, [open]);

  const reverseGeocode = (coords) => {
    setLoadingAddr(true);
    if (!window.google?.maps) {
      setLoadingAddr(false);
      setPicked({ lat: coords.lat, lng: coords.lng, endereco: `${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}` });
      return;
    }
    const g = new window.google.maps.Geocoder();
    g.geocode({ location: coords }, (res, st) => {
      setLoadingAddr(false);
      if (st === 'OK' && res[0]) setPicked({ lat: coords.lat, lng: coords.lng, endereco: res[0].formatted_address });
      else setPicked({ lat: coords.lat, lng: coords.lng, endereco: `${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}` });
    });
  };

  const handleMapClick = (coords) => {
    setSugg([]); setQuery('');
    setPicked({ lat: coords.lat, lng: coords.lng, endereco: 'Buscando endereço…' });
    reverseGeocode(coords);
  };

  const onSearch = async (v) => {
    setQuery(v);
    if (v.length < 3 || !autoRef.current) return setSugg([]);
    try {
      const r = await autoRef.current.getPlacePredictions({ input: v, componentRestrictions: { country: 'br' } });
      setSugg(r.predictions || []);
    } catch {}
  };

  const pickPlace = (placeId, desc) => {
    setSugg([]); setQuery(desc);
    if (!placesRef.current) return;
    placesRef.current.getDetails({ placeId, fields: ['geometry', 'formatted_address'] }, (place, st) => {
      if (st === window.google.maps.places.PlacesServiceStatus.OK && place.geometry) {
        setPicked({ lat: place.geometry.location.lat(), lng: place.geometry.location.lng(), endereco: place.formatted_address || desc });
      }
    });
  };

  const useCurrent = () => {
    if (!navigator.geolocation) return;
    setLoadingAddr(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        const coords = { lat: p.coords.latitude, lng: p.coords.longitude };
        setSugg([]); setQuery('');
        setPicked({ lat: coords.lat, lng: coords.lng, endereco: 'Buscando endereço…' });
        reverseGeocode(coords);
      },
      () => setLoadingAddr(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const finalLabel = () => (label === 'Outro' ? (customLabel.trim() || 'Outro') : label);

  const confirm = () => {
    if (!picked || loadingAddr) return;
    save({ ...picked, label: finalLabel() });
    onClose();
  };

  if (!open) return null;

  const mapCenter = picked ? { lat: picked.lat, lng: picked.lng } : defaultCenter;
  const showSuggestions = sugg.length > 0;
  const showPicked = picked && !showSuggestions;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" style={{ background: '#E8CEB0' }}>
      <div className="mx-auto max-w-2xl">
        <AppBar title="Escolher endereço" back={onClose} />
        <div className="px-5 pt-4">
          <div className="relative rounded-2xl overflow-hidden shadow-soft">
            <GoogleMap center={mapCenter} zoom={picked ? 16 : 13} height={260}
              markers={picked ? [{ lat: picked.lat, lng: picked.lng, title: 'Endereço' }] : []}
              onMapClick={handleMapClick} />
            <div className="absolute left-3 bottom-3 rounded-full bg-black/65 px-3 py-1.5 text-[10px] font-bold text-white pointer-events-none">
              Toque no mapa para escolher
            </div>
          </div>
        </div>

        <div className="px-5 py-4 pb-32 space-y-4">
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.Search size={16} /></span>
            <input value={query} onChange={(e) => onSearch(e.target.value)}
              placeholder="Ou digite o endereço, rua, número…"
              className="w-full rounded-2xl border border-border bg-surface pl-11 pr-4 text-sm outline-none focus:ring-2 focus:ring-terracotta"
              style={{ height: 52 }} />
          </div>

          {!showSuggestions && (
            <button onClick={useCurrent} type="button" className="w-full flex items-center gap-3 rounded-2xl bg-surface p-4 shadow-soft text-left">
              <span className="flex size-10 items-center justify-center rounded-full bg-secondary text-primary shrink-0"><I.Crosshair size={18} /></span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold">Usar minha localização atual</p>
                <p className="text-[11px] text-muted-foreground">Detectar automaticamente pelo GPS</p>
              </div>
              <I.ChevronRight size={18} className="text-muted-foreground" />
            </button>
          )}

          {showSuggestions && (
            <div className="rounded-2xl bg-surface shadow-soft overflow-hidden">
              {sugg.map((s) => (
                <button key={s.place_id} type="button" onClick={() => pickPlace(s.place_id, s.description)}
                  className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-background border-b border-border last:border-0">
                  <I.MapPin size={16} className="text-terracotta mt-0.5 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold truncate">{s.structured_formatting?.main_text || s.description}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{s.structured_formatting?.secondary_text || ''}</p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {showPicked && (
            <>
              <div className="rounded-2xl bg-surface p-4 shadow-soft">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide">Endereço selecionado</p>
                  {loadingAddr && <span className="text-[10px] text-terracotta font-bold">buscando…</span>}
                </div>
                <p className="text-sm font-semibold">{picked.endereco}</p>
              </div>

              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Identificar como</p>
                <div className="flex gap-2 mb-3">
                  {[{ v: 'Casa', i: I.Home }, { v: 'Trabalho', i: I.Store }, { v: 'Outro', i: I.MapPin }].map((o) => (
                    <button key={o.v} type="button" onClick={() => setLabel(o.v)}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-2xl py-3 text-sm font-bold transition ${label === o.v ? 'text-white' : 'bg-surface text-foreground border border-border'}`}
                      style={label === o.v ? { background: '#1C2120' } : {}}>
                      <o.i size={14} /> {o.v}
                    </button>
                  ))}
                </div>

                {label === 'Outro' && (
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"><I.Settings size={16} /></span>
                    <input value={customLabel} onChange={(e) => setCustomLabel(e.target.value.slice(0, 30))}
                      placeholder="Ex: Casa da vó, Academia, Escritório…" maxLength={30}
                      className="w-full rounded-2xl border border-border bg-surface pl-11 pr-14 text-sm outline-none focus:ring-2 focus:ring-terracotta"
                      style={{ height: 52 }} />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">{customLabel.length}/30</span>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {showPicked && (
          <div className="fixed inset-x-0 bottom-0 z-30 mx-auto max-w-2xl bg-background/95 p-5 backdrop-blur">
            <Button size="lg" onClick={confirm} style={{ background: '#3D4A2E' }} disabled={loadingAddr || (label === 'Outro' && !customLabel.trim())}>
              {loadingAddr ? 'LOCALIZANDO…' : 'Confirmar endereço'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}