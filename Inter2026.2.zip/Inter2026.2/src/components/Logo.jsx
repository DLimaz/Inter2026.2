import React from 'react';
import { I } from '../lib/icons';

export function Logo({ size = 80, dark = false }) {
  const bg = dark ? 'bg-white text-[#1C2120]' : 'bg-[#3D4A2E] text-[#E8DCC4]';
  return (
    <div style={{ width: size, height: size }} className={`flex items-center justify-center rounded-full ${bg} shrink-0 shadow-soft`}>
      <I.Cake size={size * 0.5} strokeWidth={1.6} />
    </div>
  );
}