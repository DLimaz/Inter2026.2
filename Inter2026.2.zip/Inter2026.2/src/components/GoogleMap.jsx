import React, { useEffect, useRef, useState } from 'react';
import { MAP_STYLE } from '../lib/googleMaps';
import { useGoogleMaps } from '../hooks/useGoogleMaps';
import { I } from '../lib/icons';

export function GoogleMap({ center, zoom = 14, markers = [], onMarkerClick, onMapClick, height = 320, className = '', interactive = true }) {
  const ref = useRef(null);
  const mapRef = useRef(null);
  const markersRef = useRef([]);
  const { ready, error } = useGoogleMaps();
  const [mapReady, setMapReady] = useState(false);

  useEffect(() => {
    if (!ready || !ref.current || mapRef.current) return;
    const map = new window.google.maps.Map(ref.current, {
      center: center || { lat: -23.55, lng: -46.63 },
      zoom, mapTypeControl: false, streetViewControl: false, fullscreenControl: false,
      styles: MAP_STYLE, gestureHandling: interactive ? 'auto' : 'none',
    });
    mapRef.current = map;
    if (onMapClick) map.addListener('click', e => onMapClick({ lat: e.latLng.lat(), lng: e.latLng.lng() }));
    setMapReady(true);
  }, [ready]);

  useEffect(() => {
    if (!mapReady || !mapRef.current || !center) return;
    mapRef.current.setCenter(center);
    mapRef.current.setZoom(zoom);
  }, [center?.lat, center?.lng, zoom, mapReady]);

  useEffect(() => {
    if (!mapReady || !mapRef.current) return;
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current = (markers || []).map(m => {
      const marker = new window.google.maps.Marker({ position: { lat: m.lat, lng: m.lng }, map: mapRef.current, title: m.title });
      if (onMarkerClick) marker.addListener('click', () => onMarkerClick(m));
      return marker;
    });
  }, [markers, mapReady]);

  if (error) return (
    <div className={`flex flex-col items-center justify-center bg-secondary text-center p-6 ${className}`} style={{ height }}>
      <I.Map size={32} className="text-primary/60 mb-2" />
      <p className="text-sm font-semibold text-primary">Mapa indisponível</p>
    </div>
  );
  if (!ready) return (
    <div className={`flex items-center justify-center bg-secondary ${className}`} style={{ height }}>
      <p className="text-sm text-muted-foreground">Carregando mapa…</p>
    </div>
  );
  return <div ref={ref} className={className} style={{ height, width: '100%' }} />;
}