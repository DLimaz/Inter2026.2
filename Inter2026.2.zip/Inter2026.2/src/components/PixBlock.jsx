import React, { useState, useMemo } from 'react';
import { gerarPixCopiaECola } from '../lib/pix';
import { I } from '../lib/icons';

export function PixBlock({ pixKey, pixNome, valor, compact = false }) {
  const [copied, setCopied] = useState(false);
  const code = useMemo(() => gerarPixCopiaECola(pixKey || 'pix@exemplo.com', valor, pixNome || 'LOJA'), [pixKey, pixNome, valor]);

  const copiar = async () => {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(code);
      else {
        const ta = document.createElement('textarea');
        ta.value = code; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
      }
      setCopied(true); setTimeout(() => setCopied(false), 2200);
    } catch {}
  };

  return (
    <div className={`rounded-2xl border-2 border-dashed border-primary/30 bg-secondary/40 ${compact ? 'p-3' : 'p-4'}`}>
      <div className="flex items-center gap-2 mb-3">
        <span className="flex size-7 items-center justify-center rounded-full bg-primary text-primary-foreground"><I.QrCode size={14} /></span>
        <span className="text-xs font-bold uppercase tracking-wide text-primary">Pague com PIX</span>
      </div>
      {pixKey && (
        <div className="mb-3 flex items-center gap-2 rounded-xl bg-surface px-3 py-2">
          <I.Copy size={14} className="text-muted-foreground" />
          <span className="text-xs text-muted-foreground">Chave:</span>
          <b className="text-xs text-foreground truncate">{pixKey}</b>
        </div>
      )}
      <textarea readOnly value={code} onFocus={(e) => e.target.select()} rows={compact ? 2 : 3}
        className="w-full resize-none rounded-xl border border-border bg-surface px-3 py-2 text-[10px] font-mono leading-tight text-foreground outline-none focus:ring-2 focus:ring-terracotta" />
      <button type="button" onClick={copiar}
        className={`mt-3 w-full inline-flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition active:scale-[.98] ${copied ? 'bg-green-600 text-white' : 'bg-primary text-primary-foreground hover:opacity-90'}`}>
        {copied ? <><I.Check size={16} /> Copiado! Cole no app do banco</> : <><I.Copy size={16} /> Copiar código PIX (copia e cola)</>}
      </button>
      <p className="mt-2 text-[11px] text-muted-foreground text-center">Abra o app do seu banco → PIX → <b>PIX Copia e Cola</b> → cole o código.</p>
    </div>
  );
}