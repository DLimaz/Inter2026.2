import React from 'react';

export function Input({ className = '', style, ...props }) {
  return <input className={`w-full rounded-2xl border border-border bg-surface px-4 text-sm outline-none focus:ring-2 focus:ring-terracotta transition ${className}`} style={{ height: 52, ...style }} {...props} />;
}