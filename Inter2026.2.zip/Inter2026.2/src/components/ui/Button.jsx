import React from 'react';

export function Button({ variant = 'default', size = 'default', className = '', children, ...props }) {
  const base = 'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-2xl font-bold cursor-pointer transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[.97]';
  const variants = {
    default:    'bg-moss text-moss-foreground shadow-soft hover:bg-moss/90',
    dark:       'bg-[#1C2120] text-white shadow-soft hover:opacity-90',
    black:      'bg-[#1F1A15] text-white shadow-soft hover:opacity-90',
    terracotta: 'bg-terracotta text-terracotta-foreground shadow-soft hover:opacity-90',
    cream:      'bg-surface text-primary shadow-soft hover:bg-secondary',
    outline:    'border-2 border-primary/40 text-primary bg-transparent hover:bg-primary/5',
    ghost:      'bg-transparent text-foreground hover:bg-muted',
  };
  const sizes = { default: 'h-11 px-4 text-sm', lg: 'h-14 px-8 text-base w-full', icon: 'size-11 rounded-full p-0' };
  return <button className={`${base} ${variants[variant] || variants.default} ${sizes[size] || sizes.default} ${className}`} {...props}>{children}</button>;
}