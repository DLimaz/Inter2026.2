import React from 'react';

export function Dialog({ open, onClose, children }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/45 p-0 sm:p-6 animate-rise" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-[1.7rem] sm:rounded-[1.7rem] bg-surface p-6 shadow-float max-h-[85svh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}