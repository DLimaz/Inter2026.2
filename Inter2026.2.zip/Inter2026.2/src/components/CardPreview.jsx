import React from 'react';
import { BRAND_STYLE } from '../lib/card';

export function CardPreview({ number, name, expiry, cvv, brand, flipped }) {
  const style = BRAND_STYLE[brand] || BRAND_STYLE.unknown;
  const displayNumber = number || '•••• •••• •••• ••••';
  const displayName = name || 'NOME NO CARTÃO';
  const displayExpiry = expiry || 'MM/AA';
  const displayCvv = cvv ? '•'.repeat(cvv.length) : '•••';

  return (
    <div className="relative mx-auto w-full max-w-sm" style={{ perspective: 1200 }}>
      <div className="relative w-full transition-transform duration-500"
        style={{ transformStyle: 'preserve-3d', transform: flipped ? 'rotateY(180deg)' : 'rotateY(0deg)', aspectRatio: '1.586 / 1' }}>
        <div className="absolute inset-0 rounded-[1.3rem] p-5 text-white shadow-float" style={{ background: style.bg, backfaceVisibility: 'hidden' }}>
          <div className="flex items-start justify-between">
            <div className="w-11 h-8 rounded-md bg-gradient-to-br from-yellow-200 to-yellow-500 flex items-center justify-center">
              <div className="w-6 h-4 border border-yellow-700/50 rounded-sm" />
            </div>
            <span className="text-[10px] font-extrabold tracking-widest opacity-90">{style.label}</span>
          </div>
          <p className="mt-6 sm:mt-8 font-mono text-base sm:text-lg tracking-[.12em] font-semibold drop-shadow">{displayNumber}</p>
          <div className="mt-5 flex items-end justify-between gap-4 text-[10px] uppercase opacity-90">
            <div className="min-w-0 flex-1"><p className="opacity-60 mb-0.5">Titular</p><p className="truncate text-xs font-semibold">{displayName}</p></div>
            <div className="text-right shrink-0"><p className="opacity-60 mb-0.5">Validade</p><p className="text-xs font-semibold">{displayExpiry}</p></div>
          </div>
        </div>
        <div className="absolute inset-0 rounded-[1.3rem] overflow-hidden text-white shadow-float" style={{ background: style.bg, backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}>
          <div className="h-10 bg-black/70 mt-6" />
          <div className="px-5 mt-4">
            <div className="flex items-center gap-3">
              <div className="flex-1 rounded bg-white/95 h-9 flex items-center justify-end px-3">
                <span className="font-mono text-sm text-gray-800 tracking-widest">{displayCvv}</span>
              </div>
              <span className="text-[10px] uppercase opacity-80">CVV</span>
            </div>
            <p className="mt-3 text-[10px] opacity-60">Assinatura</p>
          </div>
        </div>
      </div>
    </div>
  );
}