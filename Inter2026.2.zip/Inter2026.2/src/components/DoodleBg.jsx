import React from 'react';

export function DoodleBg() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden select-none z-0" aria-hidden="true">
      <svg viewBox="0 0 800 1200" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 w-full h-full" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M-40,200 C120,120 220,180 260,300 C300,420 200,520 120,480 C40,440 80,340 180,330 C280,320 340,440 300,580 C260,720 120,760 -20,700" stroke="#E8CEB0" strokeWidth="1.6" opacity="0.15" />
        <path d="M900,80 C700,140 600,300 640,440 C680,580 820,620 880,540 C940,460 860,380 760,410 C660,440 660,600 780,700 C900,800 900,1000 760,1120" stroke="#E8CEB0" strokeWidth="1.8" opacity="0.14" />
        <path d="M-20,320 C200,290 400,380 600,340 C800,300 900,220 1020,260" stroke="#FBF6EA" strokeWidth="1" opacity="0.10" />
        <path d="M100,-40 C160,80 260,140 380,140 C500,140 560,60 660,80 C760,100 800,180 780,240" stroke="#E8CEB0" strokeWidth="1.4" opacity="0.12" />
      </svg>
      <svg viewBox="0 0 800 1200" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 w-full h-full" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <ellipse cx="220" cy="180" rx="180" ry="120" transform="rotate(-25 220 180)" stroke="#E8CEB0" strokeWidth="1.5" opacity="0.13" />
        <ellipse cx="480" cy="500" rx="220" ry="150" transform="rotate(18 480 500)" stroke="#FBF6EA" strokeWidth="1.2" opacity="0.11" />
        <circle cx="680" cy="360" r="140" stroke="#E8CEB0" strokeWidth="1.6" opacity="0.12" />
        <ellipse cx="180" cy="720" rx="160" ry="110" transform="rotate(-15 180 720)" stroke="#E8CEB0" strokeWidth="1.4" opacity="0.10" />
      </svg>
      <svg viewBox="0 0 800 1200" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 w-full h-full" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M560,-40 C520,200 620,360 560,540 C500,720 400,860 460,1040 C500,1160 620,1200 720,1180" stroke="#E8CEB0" strokeWidth="1.6" opacity="0.14" />
        <path d="M280,1200 C240,1060 180,940 240,820 C300,700 420,700 460,820 C500,940 400,1020 320,980" stroke="#FBF6EA" strokeWidth="1.2" opacity="0.10" />
      </svg>
      <svg viewBox="0 0 400 200" className="absolute right-[8%] bottom-[10%] w-48 lg:w-64" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20,120 C40,100 60,80 70,100 C80,120 60,140 50,120 C40,100 70,90 90,110 C110,130 110,150 95,150 C80,150 85,130 105,120 C125,110 145,130 160,140 C175,150 190,140 195,120 C200,100 215,95 225,110 C235,125 225,145 215,140 C205,135 220,110 245,100 C270,90 285,110 290,130 C295,150 315,155 340,150" stroke="#E8CEB0" strokeWidth="1.6" opacity="0.22" />
        <path d="M60,170 C90,165 130,175 165,168 C200,161 240,175 280,168" stroke="#E8CEB0" strokeWidth="1.4" opacity="0.18" />
      </svg>
      <svg viewBox="0 0 400 200" className="absolute left-[8%] top-[12%] w-32 lg:w-44" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10,60 C60,20 140,40 180,90 C220,140 260,140 300,110" stroke="#FBF6EA" strokeWidth="1.4" opacity="0.12" />
      </svg>
    </div>
  );
}