import React from 'react';
import { TopNav } from './TopNav';
import { BottomNav } from './BottomNav';

export function Page({ children, screen, go, noNav = false, wide = false, dark = false }) {
  return (
    <main className="min-h-screen" style={{ background: dark ? '#1C2120' : '#E8CEB0' }}>
      <TopNav screen={screen} go={go} />
      <div className="mx-auto lg:max-w-6xl lg:px-8 lg:py-6">{children}</div>
      {!noNav && <BottomNav screen={screen} go={go} dark={dark} />}
    </main>
  );
}