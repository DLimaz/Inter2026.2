import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAddress } from '../../context/AddressContext';
import { useCart } from '../../context/CartContext';
import { I } from '../../lib/icons';
import { AddressPicker } from '../AddressPicker';

export function TopNav({ screen, go }) {
  const { user } = useAuth();
  const { address } = useAddress();
  const [pickerOpen, setPickerOpen] = useState(false);
  const { count } = useCart();

  const items = [
    { s: 'home', l: 'Início', i: I.Home },
    { s: 'map', l: 'Mapa', i: I.Map },
    { s: 'orders', l: 'Pedidos', i: I.ShoppingBag },
    { s: 'favorites', l: 'Favoritos', i: I.Heart },
  ];
  const initials = (user?.nome || 'U').split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();

  return (
    <>
      <header className="hidden lg:flex sticky top-0 z-40 items-center gap-6 px-8 py-3 border-b border-white/10 backdrop-blur-xl shadow-soft text-white" style={{ background: '#688662' }}>
        <button onClick={() => go('home')} className="flex items-center gap-3 shrink-0">
          <div className="flex size-11 items-center justify-center rounded-full bg-[#FBF6EA] overflow-hidden shrink-0">
            <img src="logo.png" alt="Doces & Salgados" className="w-full h-full object-contain" />
          </div>
          <div className="text-left">
            <p className="text-sm font-extrabold leading-none tracking-tight text-white">DOCES & SALGADOS</p>
            <p className="text-[10px] text-white/70 leading-tight">Feito perto de você</p>
          </div>
        </button>

        <button onClick={() => setPickerOpen(true)} className="flex items-center gap-1.5 rounded-full bg-white/15 hover:bg-white/25 px-3 py-2 text-xs font-semibold transition max-w-xs text-white">
          <I.MapPin size={14} className="shrink-0 text-[#E8CEB0]" />
          <span className="truncate">{address ? address.label : 'Definir endereço'}</span>
          <I.ChevronRight size={12} className="rotate-90 text-white/70 shrink-0" />
        </button>

        <nav className="flex items-center gap-1 mx-auto">
          {items.map(({ s, l, i: IconComp }) => (
            <button key={s} onClick={() => go(s)}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition ${screen === s ? 'bg-[#1C2120] text-white' : 'text-white/75 hover:bg-white/10 hover:text-white'}`}>
              <IconComp size={16} /> {l}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <button onClick={() => go('cart')} className="relative flex size-10 items-center justify-center rounded-full bg-white/15 hover:bg-white/25 transition text-white">
            <I.Cart size={18} />
            {count > 0 && <span className="absolute -top-1 -right-1 flex size-5 items-center justify-center rounded-full bg-terracotta text-white text-[10px] font-bold">{count}</span>}
          </button>
          <button onClick={() => go('profile')} aria-label="Perfil"
            className="flex size-10 items-center justify-center rounded-full bg-[#1C2120] text-white text-xs font-extrabold hover:opacity-90 transition overflow-hidden">
            {user?.avatar ? <img src={user.avatar} alt={user.nome} className="size-full object-cover" /> : initials}
          </button>
        </div>
      </header>
      <AddressPicker open={pickerOpen} onClose={() => setPickerOpen(false)} />
    </>
  );
}