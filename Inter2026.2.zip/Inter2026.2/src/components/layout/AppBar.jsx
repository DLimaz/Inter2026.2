import React from 'react';
import { Button } from '../ui/Button';
import { I } from '../../lib/icons';

export function AppBar({ title, back, right, dark = false }) {
  if (dark) {
    return (
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 text-white lg:rounded-b-none"
        style={{ background: '#1C2120', height: 60, borderRadius: '0 0 24px 24px', boxShadow: '0 4px 14px rgba(0,0,0,0.25)' }}>
        <button onClick={back} className="flex items-center justify-center size-9 -ml-2 rounded-full hover:bg-white/10 transition">
          {back && <I.ArrowLeft size={20} />}
        </button>
        <span className="text-base font-bold">{title}</span>
        <div className="min-w-6 flex justify-end">{right}</div>
      </div>
    );
  }
  return (
    <header className="flex items-center justify-between px-5 py-5 lg:px-0 lg:pt-0">
      <div className="flex items-center gap-3">
        {back && <Button size="icon" variant="cream" onClick={back}><I.ArrowLeft size={16} /></Button>}
        <h1 className="text-xl font-extrabold">{title}</h1>
      </div>
      {right}
    </header>
  );
}