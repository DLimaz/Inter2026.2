import React from 'react';
import { I } from '../../lib/icons';

export function BottomNav({ screen, go, dark = false }) {
  const items = [
    { s: 'home', l: 'Início', i: I.Home },
    { s: 'map', l: 'Mapa', i: I.Map },
    { s: 'orders', l: 'Pedidos', i: I.ShoppingBag },
    { s: 'favorites', l: 'Favoritos', i: I.Heart },
    { s: 'profile', l: 'Perfil', i: I.User },
  ];
  return (
    <nav className={`lg:hidden fixed bottom-3 left-1/2 z-40 flex w-[calc(100%-1.5rem)] max-w-xl -translate-x-1/2 items-center justify-around rounded-[1.7rem] px-2 py-2 shadow-float backdrop-blur-xl border ${dark ? 'border-white/10' : 'border-border'}`}
      style={{ background: dark ? 'rgba(28,33,32,0.95)' : 'rgba(251,246,234,0.95)' }}>
      {items.map(({ s, l, i: IconComp }) => {
        const active = screen === s;
        return (
          <button key={s} onClick={() => go(s)} aria-label={l}
            className={`flex min-w-14 flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[10px] font-bold transition ${active ? (dark ? 'text-white' : 'bg-[#1C2120] text-white') : (dark ? 'text-white/40 hover:text-white/80' : 'text-muted-foreground hover:bg-muted')}`}>
            <IconComp size={20} /><span>{l}</span>
          </button>
        );
      })}
    </nav>
  );
}