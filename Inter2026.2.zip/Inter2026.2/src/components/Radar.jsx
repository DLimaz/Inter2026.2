import React, { useState } from 'react';
import { haversine, bearingRad, fmtKm } from '../lib/geo';
import { I } from '../lib/icons';

export function Radar({ userLoc, stores, onSelectStore, rangeKm = 5, size = 320 }) {
  const [hovered, setHovered] = useState(null);
  if (!userLoc) {
    return (
      <div className="mx-auto flex flex-col items-center justify-center rounded-full bg-secondary/60 border-2 border-dashed border-primary/25" style={{ width: size, height: size }}>
        <I.Crosshair size={32} className="text-primary/50 mb-2" />
        <p className="text-sm font-semibold text-primary px-6 text-center">Ative sua localização para ver o radar de lojas</p>
      </div>
    );
  }
  const cx = size / 2, cy = size / 2;
  const R = size / 2 - 28;
  const positioned = stores.map(s => {
    const d = haversine(userLoc.lat, userLoc.lng, s.latitude, s.longitude);
    const brg = bearingRad(userLoc.lat, userLoc.lng, s.latitude, s.longitude);
    const r = Math.min(d / rangeKm, 1) * R;
    return { store: s, distance: d, x: cx + r * Math.sin(brg), y: cy - r * Math.cos(brg) };
  }).filter(p => p.distance <= rangeKm);

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        {[0.25, 0.5, 0.75, 1].map(f => <div key={f} className="absolute rounded-full border border-primary/15" style={{ inset: `${(1 - f) * 50}%` }} />)}
        <div className="absolute left-0 right-0 top-1/2 h-px bg-primary/10" />
        <div className="absolute top-0 bottom-0 left-1/2 w-px bg-primary/10" />
        <div className="radar-sweep absolute inset-0 rounded-full" style={{ background: 'conic-gradient(from 0deg, transparent 0deg, rgba(193,98,45,0.28) 22deg, transparent 50deg)' }} />
        {[1, 2, 3, 5].filter(k => k <= rangeKm).map(k => (
          <span key={k} className="absolute text-[10px] font-bold text-primary/40" style={{ left: '50%', top: `${(1 - k / rangeKm) * 50}%`, transform: 'translate(-50%, -6px)' }}>{k}km</span>
        ))}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="pulse-ring absolute inset-0 rounded-full bg-primary/30" />
          <div className="relative size-4 rounded-full bg-primary ring-4 ring-surface shadow-float" />
        </div>
        {positioned.map(({ store, distance, x, y }) => (
          <button key={store.id} onMouseEnter={() => setHovered(store.id)} onMouseLeave={() => setHovered(null)} onClick={() => onSelectStore(store)}
            className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 group" style={{ left: x, top: y }}>
            <span className={`flex size-10 items-center justify-center rounded-full bg-terracotta text-terracotta-foreground shadow-float ring-2 ring-surface transition-transform group-hover:scale-110 ${hovered === store.id ? 'scale-110' : ''}`}>
              <I.Store size={20} />
            </span>
            {hovered === store.id && (
              <span className="float-up absolute top-full mt-1 whitespace-nowrap rounded-full bg-primary px-3 py-1 text-[10px] font-bold text-primary-foreground shadow-float">
                {store.nome} · {fmtKm(distance)}
              </span>
            )}
          </button>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-3 text-[11px] text-muted-foreground">
        <span className="flex items-center gap-1"><span className="size-3 rounded-full bg-primary" /> Você</span>
        <span className="flex items-center gap-1"><span className="size-3 rounded-full bg-terracotta" /> Lojas</span>
        <span>Raio: {rangeKm}km</span>
      </div>
    </div>
  );
}