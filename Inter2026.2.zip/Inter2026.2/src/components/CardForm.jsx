import React, { useState } from 'react';
import { detectCardBrand, maskCardNumber, maskExpiry, maskCVV, maskName, BRAND_STYLE } from '../lib/card';
import { CardPreview } from './CardPreview';

export function CardForm({ data, onChange, errors }) {
  const [focused, setFocused] = useState(null);
  const brand = detectCardBrand(data.number);

  const set = (field) => (e) => {
    let v = e.target.value;
    if (field === 'number') v = maskCardNumber(v);
    else if (field === 'expiry') v = maskExpiry(v);
    else if (field === 'cvv') v = maskCVV(v, brand);
    else if (field === 'name') v = maskName(v);
    onChange({ ...data, [field]: v });
  };

  const baseInput = 'w-full rounded-2xl border bg-surface px-4 text-sm outline-none focus:ring-2 focus:ring-terracotta transition';

  return (
    <div className="space-y-4">
      <CardPreview number={data.number} name={data.name} expiry={data.expiry} cvv={data.cvv} brand={brand} flipped={focused === 'cvv'} />
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-1.5">Número do cartão</label>
          <div className="relative">
            <input inputMode="numeric" autoComplete="cc-number" value={data.number} onChange={set('number')}
              onFocus={() => setFocused('number')} onBlur={() => setFocused(null)} placeholder="0000 0000 0000 0000"
              className={`${baseInput} font-mono ${errors?.number ? 'border-red-400' : 'border-border'}`} style={{ height: 52 }} />
            {brand && brand !== 'unknown' && <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-extrabold text-primary tracking-wider">{BRAND_STYLE[brand].label}</span>}
          </div>
          {errors?.number && <p className="mt-1 text-xs text-red-500">{errors.number}</p>}
        </div>
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-1.5">Nome impresso no cartão</label>
          <input autoComplete="cc-name" value={data.name} onChange={set('name')} onFocus={() => setFocused('name')} onBlur={() => setFocused(null)}
            placeholder="COMO ESTÁ NO CARTÃO" className={`${baseInput} ${errors?.name ? 'border-red-400' : 'border-border'}`} style={{ height: 52 }} />
          {errors?.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-muted-foreground mb-1.5">Validade</label>
            <input inputMode="numeric" autoComplete="cc-exp" value={data.expiry} onChange={set('expiry')} onFocus={() => setFocused('expiry')} onBlur={() => setFocused(null)}
              placeholder="MM/AA" className={`${baseInput} font-mono ${errors?.expiry ? 'border-red-400' : 'border-border'}`} style={{ height: 52 }} />
            {errors?.expiry && <p className="mt-1 text-xs text-red-500">{errors.expiry}</p>}
          </div>
          <div>
            <label className="block text-xs font-bold text-muted-foreground mb-1.5">CVV</label>
            <input inputMode="numeric" autoComplete="cc-csc" value={data.cvv} onChange={set('cvv')} onFocus={() => setFocused('cvv')} onBlur={() => setFocused(null)}
              placeholder={brand === 'amex' ? '0000' : '000'} className={`${baseInput} font-mono ${errors?.cvv ? 'border-red-400' : 'border-border'}`} style={{ height: 52 }} />
            {errors?.cvv && <p className="mt-1 text-xs text-red-500">{errors.cvv}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}