export const FOTOS_PRODUTOS = {
  brigadeiro: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500&q=80&auto=format&fit=crop',
  coxinha:    'https://images.pexels.com/photos/17409458/pexels-photo-17409458.jpeg',
  boloChoc:   'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&q=80&auto=format&fit=crop',
  paoQueijo:  'https://images.unsplash.com/photo-1592894869086-f828b161e90a?w=500&q=80&auto=format&fit=crop',
  beijinho:   'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=500&q=80&auto=format&fit=crop',
  refri:      'https://images.unsplash.com/photo-1554866585-cd94860890b7?w=500&q=80&auto=format&fit=crop',
  tortaLimao: 'https://images.unsplash.com/photo-1519915028121-7d3463d20b13?w=500&q=80&auto=format&fit=crop',
  empada:     'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&q=80&auto=format&fit=crop',
  boloCenoura:'https://images.unsplash.com/photo-1621303837174-89787a7d4729?w=500&q=80&auto=format&fit=crop',
  risoles:    'https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?w=500&q=80&auto=format&fit=crop',
};

export const FOTOS_LOJAS = {
  casaAmora:  'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=700&q=80&auto=format&fit=crop',
  doceAfeto:  'https://images.unsplash.com/photo-1486427944299-d1955d23e34d?w=700&q=80&auto=format&fit=crop',
  fornoFesta: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=700&q=80&auto=format&fit=crop',
};