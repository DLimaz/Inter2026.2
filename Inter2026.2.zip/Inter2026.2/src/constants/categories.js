import { I } from '../lib/icons';

export const CATEGORIES = [
  { n: 'Doces',    i: I.Candy,    color: '#E8DCC4' },
  { n: 'Salgados', i: I.Sandwich, color: '#E8DCC4' },
  { n: 'Bolos',    i: I.Cake,     color: '#E8DCC4' },
  { n: 'Bebidas',  i: I.Coffee,   color: '#E8DCC4' },
];